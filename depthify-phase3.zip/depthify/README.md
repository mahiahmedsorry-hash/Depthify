# DEPTHIFY — YOUR WALLPAPER. YOUR DEPTH.

Native Android depth-wallpaper app (Kotlin + Jetpack Compose). Premium AMOLED dark + gold (`#FFD600`). Image processing is on-device. No accounts, photo uploads, analytics or network permission.

## Build the APK with GitHub Actions
1. Upload the complete project folder to your GitHub repository, keeping `.github/workflows/build-apk.yml` and the directory structure.
2. Open **Actions** → **Build APK** → **Run workflow** (pushes to `main` also trigger it).
3. Download the `depthify-debug-apk` artifact and install `app-debug.apk` on your Android phone.
4. If the workflow fails, send the first Kotlin/Gradle error block. This project has not been compiled in this environment.

## Stack
Kotlin 2.0.21 · AGP 8.7.3 · Compose BOM 2024.12.01 · Material 3 · Navigation Compose 2.8.5 · DataStore · minSdk 26 · targetSdk 35 · JDK 17.

## Roadmap
| Phase | Scope | Status |
|---|---|---|
| 1 | Project setup, theme, navigation, UI shell, onboarding | Done in previous phase |
| 2 | Wallpaper gallery and image import | Written, untested |
| 3 | Person segmentation, manual mask editor, transparent foreground storage | **Written, untested** |
| 4 | Layer composition and depth rendering | Not started |
| 5 | Text, clock, date, advanced editor | Not started |
| 6 | Static export and live wallpaper | Not started |
| 7 | Room database, testing, optimization, release | Not started |

## Phase 3 features
- **Quick Mode → Cutout** opens the Phase 3 editor.
- Android Photo Picker selects one image. `ImportedPhotoStore` copies the untouched bytes to `filesDir/originals`. SHA-256 comparison reuses an existing imported copy when the same image is selected again.
- Person mode uses the bundled Google ML Kit Selfie Segmentation model offline. The working image is downscaled to a maximum 1024 px long side; confidence is softened and the mask is resized smoothly for preview.
- Cars, aircraft, animals, anime and other non-person subjects use Manual Mask. Erase/restore brushes have a soft radial edge; brush size, undo/redo, pinch zoom and pan are provided.
- Mask editing uses preview-resolution bitmaps. Saving decodes the stored original again (up to a 4096 px long side for memory safety), scales the edited mask smoothly, and writes `mask.png`, `foreground.png` and `metadata.properties` under `filesDir/cutouts/<photo-id>/`.
- Automatic results are cached. Selecting the same original again opens the cached mask and foreground rather than running segmentation again.
- Library includes a **My cutouts** section. Phase 4 can load the transparent `foreground.png` as a foreground layer.
- Original photos are never modified. The only source image kept is the app-private copy.

## ML Kit dependency note
`com.google.mlkit:segmentation-selfie:16.0.0-beta6` is pinned exactly and uses the bundled model, so inference does not require a model download. Google currently documents this Selfie Segmentation artifact as a **beta** API; a stable release is not published in the official Android setup page at the time this phase was authored. The model adds roughly 4.5 MB to the app. See the [official ML Kit Android guide](https://developers.google.com/ml-kit/vision/selfie-segmentation/android).

## Adding a future MediaPipe / LiteRT subject model
No non-person model is included or downloaded by this phase. The integration point is:

1. Put your legally usable `.tflite` model at `app/src/main/assets/models/subject_segmenter.tflite` (the folder already exists).
2. Inspect that model's published model card and document its exact input tensor shape, colour order, numeric type/range, output tensor shape and mask meaning. Do not assume every segmentation model has the same tensors.
3. Add a pinned, compatible LiteRT runtime dependency to `app/build.gradle.kts` (or MediaPipe Tasks dependency if the model is packaged for Tasks). Keep `google()` and `mavenCentral()` repositories in `settings.gradle.kts`.
4. Implement `SubjectSegmenter` in `segmentation/` using the model's documented tensor contract. Its `segment(Bitmap)` method must return a same-aspect-ratio white foreground / black background alpha mask, with confidence preserved as soft alpha where possible.
5. Resize the model input without distorting aspect ratio, run inference on `Dispatchers.Default` or `Dispatchers.IO`, close the interpreter/task resources, and resize the output mask smoothly to the supplied image dimensions.
6. Route non-person subjects to that implementation in `CutoutViewModel`; keep `MlKitPersonSegmenter` for people. Add model-specific device tests before enabling it by default.

Do not just copy an arbitrary `.tflite` file into assets: the model's input/output tensor contract must match the implementation.

## Permissions and privacy
- `SET_WALLPAPER` is used to apply wallpapers.
- `WRITE_EXTERNAL_STORAGE` is limited to Android 8 and 9 for saving to shared Pictures storage.
- Photo Picker is used for image selection; no broad gallery permission is requested.
- Imported originals, masks, metadata and foreground PNGs remain in app-private storage. No image is uploaded. There is no internet permission or analytics SDK.

## Phase 3 phone testing checklist
- [ ] GitHub Actions build succeeds; install the debug APK.
- [ ] Create → Quick Mode → Choose Photo opens Android Photo Picker.
- [ ] Select a photo and confirm the original still exists unchanged in the gallery.
- [ ] Select the same photo again and confirm no second original copy is created.
- [ ] With a clear person photo, Auto Cutout produces a transparent preview and keeps hair/edge transitions reasonably smooth.
- [ ] Turn off internet before testing and confirm bundled person segmentation still works.
- [ ] Select a car/animal/anime/object photo and use Manual Mask; erase and restore both work.
- [ ] Change brush size; test soft edges, undo, redo, reset, pinch zoom and pan.
- [ ] Cancel segmentation and confirm the screen returns to an idle state.
- [ ] Save and confirm `mask.png`, `foreground.png` and `metadata.properties` exist in app-private storage through app behaviour (not a public gallery folder).
- [ ] Reopen the same original and confirm cached cutout loads without repeating automatic segmentation.
- [ ] Library → My cutouts displays saved foreground previews.
- [ ] Try a large photo and confirm the app remains responsive and shows a readable error rather than closing if memory is insufficient.
- [ ] Confirm Settings privacy text matches the actual on-device processing behaviour.

## Known limitations
- **Written, untested:** no Android SDK or network is available in the authoring environment, so this ZIP has not been compiled, installed or tested. ML Kit dependency resolution and Compose/Kotlin API compatibility must be confirmed by GitHub Actions.
- ML Kit Selfie Segmentation is beta and intended for people. It is not a general object segmenter; use the manual mask for other subjects until a compatible model is added.
- Cancellation stops the app coroutine/UI operation; the underlying ML Kit task may finish internally because its Task API does not expose a cancellation handle.
- The editor mask is preview resolution. To limit memory use, the saved foreground is currently capped at a 4096 px long side; the untouched original remains available. Full original-resolution tiled export is future optimization work.
- Automatic cutout cache is created at preview resolution first; pressing Save writes the higher-resolution foreground and mask.
- `My cutouts` is a simple file-backed list, not a Room database. Project management arrives in Phase 7.
- Lock-screen wallpaper support varies by phone maker. No release signing is configured.
