package com.depthify.ui.cutout

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.depthify.data.repository.CutoutStore
import com.depthify.data.repository.ImportedPhotoStore
import com.depthify.segmentation.MlKitPersonSegmenter
import com.depthify.core.image.BitmapDecoder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

data class CutoutUiState(
    val originalName: String? = null,
    val preview: Bitmap? = null,
    val mask: Bitmap? = null,
    val foreground: Bitmap? = null,
    val busy: Boolean = false,
    val progress: String = "",
    val error: String? = null,
    val saved: Boolean = false,
    val manualMode: Boolean = false
)

class CutoutViewModel(application: Application) : AndroidViewModel(application) {
    private val imported = ImportedPhotoStore(getApplication<Application>())
    private val store = CutoutStore(getApplication<Application>())
    private var activeJob: Job? = null
    private val _state = MutableStateFlow(CutoutUiState())
    val state: StateFlow<CutoutUiState> = _state.asStateFlow()

    fun choose(uri: android.net.Uri) {
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _state.value = CutoutUiState(busy = true, progress = "Copying original photo…")
            try {
                val item = withContext(Dispatchers.IO) {
                    imported.importFrom(getApplication<Application>().contentResolver, uri)
                }
                val name = (item.source as com.depthify.core.models.WallpaperSource.Imported).fileName
                val cached = withContext(Dispatchers.IO) { store.entry(name) }
                if (cached != null) {
                    loadCached(name)
                    return@launch
                }
                val file = imported.file(name)
                val preview = withContext(Dispatchers.IO) { decodeOriented(file, 1024) }
                    ?: error("This photo could not be decoded.")
                _state.value = CutoutUiState(originalName = name, preview = preview, busy = false)
                activeJob = null
                runPersonSegmentation()
            } catch (e: Exception) {
                _state.value = CutoutUiState(error = e.message ?: "Could not open this photo.")
            }
        }
    }

    fun loadCached(name: String) {
        viewModelScope.launch {
            _state.value = CutoutUiState(busy = true, progress = "Opening saved cutout…")
            try {
                val file = imported.file(name)
                val pair = withContext(Dispatchers.IO) {
                    val original = decodeOriented(file, 1024) ?: error("Original photo is unavailable.")
                    val entry = store.entry(name) ?: error("Saved cutout not found.")
                    val rawMask = decodeMaskPreview(entry.maskFile) ?: error("Mask file is unavailable.")
                    val mask = scaleMask(rawMask, original.width, original.height)
                    rawMask.recycle()
                    original to mask
                }
                _state.value = CutoutUiState(originalName = name, preview = pair.first, mask = pair.second, foreground = composite(pair.first, pair.second))
            } catch (e: Exception) {
                _state.value = CutoutUiState(error = e.message ?: "Could not open cutout.")
            }
        }
    }

    fun runPersonSegmentation() {
        val current = _state.value
        val source = current.preview ?: return
        val name = current.originalName ?: return
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _state.value = current.copy(busy = true, progress = "Finding the person…", error = null)
            try {
                val mask = withContext(Dispatchers.Default) { MlKitPersonSegmenter().segment(source) }
                val foreground = withContext(Dispatchers.Default) { composite(source, mask) }
                _state.value = current.copy(mask = mask, foreground = foreground, busy = false, progress = "", manualMode = false)
                cachePreview(name, mask, foreground)
            } catch (e: CancellationException) {
                _state.value = _state.value.copy(busy = false, progress = "", error = "Segmentation cancelled.")
                throw e
            } catch (e: Exception) {
                _state.value = _state.value.copy(busy = false, progress = "", error = "Person segmentation failed. You can use Manual Mask for this photo.")
            }
        }
    }

    fun startManualMask() {
        val current = _state.value
        val source = current.preview ?: return
        val mask = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.WHITE) }
        _state.value = current.copy(mask = mask, foreground = source.copy(Bitmap.Config.ARGB_8888, true), error = null, manualMode = true)
    }

    fun updateMask(mask: Bitmap) {
        val current = _state.value
        val source = current.preview ?: return
        _state.value = current.copy(mask = mask, foreground = composite(source, mask), saved = false)
    }

    fun save() {
        val current = _state.value
        val name = current.originalName ?: return
        val mask = current.mask ?: return
        _state.value = current.copy(busy = true, progress = "Saving transparent foreground…", error = null)
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val original = decodeOriented(imported.file(name), 4096) ?: error("Original photo could not be decoded.")
                    val fullMask = scaleMask(mask, original.width, original.height)
                    val foreground = composite(original, fullMask)
                    store.save(name, name, fullMask, foreground)
                    original.recycle()
                    fullMask.recycle()
                    foreground.recycle()
                }
                _state.value = _state.value.copy(busy = false, progress = "", saved = true)
            } catch (e: OutOfMemoryError) {
                _state.value = _state.value.copy(busy = false, progress = "", error = "This photo is too large for available memory. Try a smaller copy.")
            } catch (e: Exception) {
                _state.value = _state.value.copy(busy = false, progress = "", error = e.message ?: "Could not save cutout.")
            }
        }
    }

    private suspend fun cachePreview(name: String, mask: Bitmap, foreground: Bitmap) {
        withContext(Dispatchers.IO) { store.save(name, name, mask, foreground) }
    }

    fun cancelWork() {
        activeJob?.cancel()
        activeJob = null
        _state.value = _state.value.copy(busy = false, progress = "", error = "Operation cancelled.")
    }

    fun cutouts(): List<CutoutStore.Entry> = store.list()

    private fun decodeOriented(file: File, maxSide: Int): Bitmap? {
        val size = BitmapDecoder.readSize(file) ?: return null
        var sample = 1
        while (maxOf(size.width, size.height) / sample > maxSide) sample *= 2
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: return null
        val orientation = runCatching {
            ExifInterface(file.absolutePath).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        }.getOrDefault(1)
        val matrix = Matrix().apply {
            when (orientation) {
                2 -> postScale(-1f, 1f)
                3 -> postRotate(180f)
                4 -> postScale(1f, -1f)
                5 -> { postRotate(90f); postScale(-1f, 1f) }
                6 -> postRotate(90f)
                7 -> { postRotate(270f); postScale(-1f, 1f) }
                8 -> postRotate(270f)
            }
        }
        val oriented = if (orientation == 1) decoded else Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true).also { if (it !== decoded) decoded.recycle() }
        val ratio = maxOf(oriented.width, oriented.height).toFloat() / maxSide
        if (ratio <= 1f) return oriented
        val scaled = Bitmap.createScaledBitmap(oriented, (oriented.width / ratio).toInt().coerceAtLeast(1), (oriented.height / ratio).toInt().coerceAtLeast(1), true)
        if (scaled !== oriented) oriented.recycle()
        return scaled
    }

    private fun decodeMaskPreview(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        })
    }

    private fun scaleMask(mask: Bitmap, width: Int, height: Int): Bitmap =
        Bitmap.createScaledBitmap(mask, width, height, true).copy(Bitmap.Config.ARGB_8888, true)

    private fun composite(source: Bitmap, mask: Bitmap): Bitmap {
        val output = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(mask, null, Rect(0, 0, output.width, output.height), paint)
        paint.xfermode = null
        return output
    }
}