package com.depthify.engine.wallpaper

import android.graphics.BitmapFactory
import android.graphics.Rect
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File

/** Battery-conscious live wallpaper service: redraws only on visibility/surface changes. */
class DepthifyWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = DepthifyEngine()

    private inner class DepthifyEngine : Engine() {
        private var visibleNow = false
        private var bitmap: android.graphics.Bitmap? = null

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            loadLatest()
        }

        private fun loadLatest() {
            bitmap?.recycle()
            val folder = File(filesDir, "exports")
            val file = listOf("latest_wallpaper.png", "latest_wallpaper.jpg")
                .map { File(folder, it) }.firstOrNull { it.exists() }
            bitmap = file?.let { BitmapFactory.decodeFile(it.absolutePath) }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            visibleNow = visible
            if (visibleNow) {
                loadLatest()
                drawFrame()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        private fun drawFrame() {
            if (!visibleNow) return
            val canvas = runCatching { surfaceHolder.lockCanvas() }.getOrNull() ?: return
            try {
                canvas.drawColor(android.graphics.Color.BLACK)
                val image = bitmap
                if (image != null && !image.isRecycled) {
                    val scale = maxOf(canvas.width.toFloat() / image.width, canvas.height.toFloat() / image.height)
                    val w = image.width * scale
                    val h = image.height * scale
                    val dst = Rect(((canvas.width - w) / 2).toInt(), ((canvas.height - h) / 2).toInt(), ((canvas.width + w) / 2).toInt(), ((canvas.height + h) / 2).toInt())
                    canvas.drawBitmap(image, null, dst, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                }
            } finally {
                runCatching { surfaceHolder.unlockCanvasAndPost(canvas) }
            }
        }

        override fun onDestroy() {
            visibleNow = false
            bitmap?.recycle()
            bitmap = null
            super.onDestroy()
        }
    }
}
