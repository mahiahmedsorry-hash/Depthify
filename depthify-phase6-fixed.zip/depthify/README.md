# DEPTHIFY — YOUR WALLPAPER. YOUR DEPTH.

Native Android depth-wallpaper app (Kotlin + Jetpack Compose). Premium AMOLED dark + gold (`#FFD600`). Image processing is on-device. No accounts, photo uploads, analytics or network permission.

## Build the APK with GitHub Actions
1. Upload the complete project folder to your GitHub repository, keeping `.github/workflows/build-apk.yml` and the directory structure.
2. Open **Actions** → **Build APK** → **Run workflow** (pushes to `main` also trigger it).
3. Download the `depthify-debug-apk` artifact and install `app-debug.apk` on your Android phone.
4. If the workflow fails, send the first Kotlin/Gradle error block. This project has not been compiled in this environment.

## Stack
Kotlin 2.0.21 · AGP 8.7.3 · Compose BOM 2024.12.01 · Material 3 · Navigation Compose 2.8.5 · DataStore · minSdk 26 · targetSdk 35 · JDK 17.

## Roadmap
| Phase | Scope | Status |
|---|---|---|
| 1 | Project setup, theme, navigation, UI shell, onboarding | Done in previous phase |
| 2 | Wallpaper gallery and image import | Written, untested |
| 3 | Person segmentation, manual mask editor, transparent foreground storage | **Written, untested** |
| 4 | Layer composition, backgrounds and depth controls | **Written, untested** |
| 5 | Editable text layers, typography and presets | **Partially written, untested** |
| 6 | PNG/JPEG export, static wallpaper apply and static live wallpaper service | **Partially written, untested** |
| 7 | Room database, testing, optimization, release | Not started |

## Phase 3 features
- **Quick Mode → Cutout** opens the Phase 3 editor.
- Android Photo Picker selects one image. `ImportedPhotoStore` copies the untouched bytes to `filesDir/originals`. SHA-256 comparison reuses an existing imported copy when the same image is selected again.
- Person mode uses the bundled Google ML Kit Selfie Segmentation model offline. The working image is downscaled to a maximum 1024 px long side; confidence is softened and the mask is resized smoothly for preview.
- Cars, aircraft, animals, anime and other non-person subjects use Manual Mask. Erase/restore brushes have a soft radial edge; brush size, undo/redo, pinch zoom and pan are provided.
- Mask editing uses preview-resolution bitmaps. Saving decodes the stored original again (up to a 4096 px long side for memory safety), scales the edited mask smoothly, and writes `mask.png`, `foreground.png` and `metadata.properties` under `filesDir/cutouts/<photo-id>/`.
- Automatic results are cached. Selecting the same original again opens the cached mask and foreground rather than running segmentation again.
- Library includes a **My cutouts** section. Phase 4 can load the transparent `foreground.png` as a foreground layer.
- Original photos are never modified. The only source image kept is the app-private copy.

## Image orientation dependency

- Uses `androidx.exifinterface:exifinterface:1.3.7` for consistent EXIF orientation reading in imported-photo decoding and cutout processing.
- Coil is not included because the current project does not use Coil APIs; thumbnails/previews are handled by the existing bitmap/Compose implementation. Add Coil only if a future screen adopts it.

## ML Kit dependency note
`com.google.mlkit:segmentation-selfie:16.0.0-beta6` is pinned exactly and uses the bundled model, so inference does not require a model download. Google currently documents this Selfie Segmentation artifact as a **beta** API; a stable release is not published in the official Android setup page at the time this phase was authored. The model adds roughly 4.5 MB to the app. See the [official ML Kit Android guide](https://developers.google.com/ml-kit/vision/selfie-segmentation/android).

## Adding a future MediaPipe / LiteRT subject model
No non-person model is included or downloaded by this phase. The integration point is:

1. Put your legally usable `.tflite` model at `app/src/main/assets/models/subject_segmenter.tflite` (the folder already exists).
2. Inspect that model's published model card and document its exact input tensor shape, colour order, numeric type/range, output tensor shape and mask meaning. Do not assume every segmentation model has the same tensors.
3. Add a pinned, compatible LiteRT runtime dependency to `app/build.gradle.kts` (or MediaPipe Tasks dependency if the model is packaged for Tasks). Keep `google()` and `mavenCentral()` repositories in `settings.gradle.kts`.
4. Implement `SubjectSegmenter` in `segmentation/` using the model's documented tensor contract. Its `segment(Bitmap)` method must return a same-aspect-ratio white foreground / black background alpha mask, with confidence preserved as soft alpha where possible.
5. Resize the model input without distorting aspect ratio, run inference on `Dispatchers.Default` or `Dispatchers.IO`, close the interpreter/task resources, and resize the output mask smoothly to the supplied image dimensions.
6. Route non-person subjects to that implementation in `CutoutViewModel`; keep `MlKitPersonSegmenter` for people. Add model-specific device tests before enabling it by default.

Do not just copy an arbitrary `.tflite` file into assets: the model's input/output tensor contract must match the implementation.

## Phase 4–6 features (written, untested)

### Phase 4 — Depth Studio
- Create → **Open Studio** lists saved Phase 3 cutouts from `CutoutStore`; if none exist, the editor shows an empty state.
- Imports a background with Android Photo Picker and copies it into app-private `filesDir/studio/backgrounds/`. Built-in solid black and deep-blue backgrounds are available.
- The composition has background and foreground subject layers, visibility toggles, subject lock, drag positioning, scale, rotation, centering/reset, brightness controls and a background blur approximation.
- The foreground PNG remains untouched; layer transforms are render-time settings.
- The composition preview and export use the shared `StudioRenderer` implementation.

### Phase 5 — Text and visual styling
- Adds editable text layers, multiple layers, duplicate/delete, visibility, lock, reorder, drag positioning, scale, rotation, opacity, color swatches, font size, bold/italic, shadow and outline.
- Includes functional Minimal, Modern, Bold, Elegant, Digital and Clock-style text presets. These create editable text layers; the clock-style preset is a text template, not a live clock.
- Text remains editable in the Studio session until export. The current project does not persist a complete editable Studio document across app restarts.

### Phase 6 — Export and wallpaper
- Renders PNG or JPEG at 720p, 1080p or 1440p portrait presets. Render output is capped at 4096 px per dimension by the renderer; selected presets are below this limit.
- Export rendering runs on `Dispatchers.IO`/`Dispatchers.Default` and saves a private latest-export copy under `filesDir/exports/`.
- Android 10+ saves to `Pictures/DEPTHIFY` through MediaStore. Android 8–9 uses the system document picker to choose a destination, avoiding a broad storage permission prompt.
- Home, Lock and Both actions show an in-app confirmation and call `WallpaperManager` to apply the exported bitmap. Device/OEM support can vary.
- Adds an Android `WallpaperService`. It loads the most recent private export and redraws only on visibility/surface changes. It is a static, battery-conscious live-wallpaper service; it does not implement depth parallax or continuous animation.

### Phase 4–6 limitations
- The Studio currently exposes the subject and background as the primary image layers. It does not yet provide arbitrary multi-image layer creation or a full layer timeline.
- Undo/redo history, original/custom export dimensions, export file-size estimation, and an export-cancel action are not implemented.
- Text alignment is available, but advanced gradient text, per-line spacing, and custom font importing are not implemented. The built-in presets use Android system sans-serif typefaces.
- The clock-style preset is static sample text; no live clock/date layer exists yet.
- Background blur is an inexpensive downscale/upscale approximation, not a depth-aware blur. There is no real depth map or parallax simulation.
- Live Wallpaper is a static display of the latest exported image. Android's system preview/enable flow is used; the user must explicitly confirm enabling it.
- The export file is private and the MediaStore/document-picker copy is separate. The service reads the private latest export.
- The editor's transient settings/text layers are not yet saved as a reusable project document; that is planned for Phase 7 project persistence.

## Permissions and privacy
- `SET_WALLPAPER` is used to apply wallpapers.
- `BIND_WALLPAPER` is declared only on the Live Wallpaper service so Android can bind to it.
- `WRITE_EXTERNAL_STORAGE` is limited to Android 8 and 9 for saving to shared Pictures storage.
- Photo Picker is used for image selection; no broad gallery or storage permission is requested. Android 8–9 exports use the system document picker.
- Imported originals, masks, metadata and foreground PNGs remain in app-private storage. No image is uploaded. There is no internet permission or analytics SDK.

## Phase 4–6 phone testing checklist
- [ ] Create → Open Studio lists all saved Phase 3 cutouts.
- [ ] With no saved cutouts, Studio displays a clear empty state.
- [ ] Import a background; confirm it remains app-private and preview updates.
- [ ] Switch solid backgrounds and test background visibility/brightness/blur.
- [ ] Drag, scale, rotate, center and reset the foreground; verify the saved source cutout remains unchanged.
- [ ] Toggle foreground visibility and lock.
- [ ] Add, edit, duplicate, hide, lock, reorder and delete text layers.
- [ ] Test text color, size, scale, rotation, opacity, bold, italic, shadow, outline, alignment and presets.
- [ ] Export PNG and JPEG at each resolution preset; verify dimensions and image quality.
- [ ] On Android 10+, confirm export appears in Pictures/DEPTHIFY; on Android 8–9, confirm document picker saves to the chosen destination.
- [ ] Apply Home, Lock and Both and verify device/OEM behaviour.
- [ ] Open Live Wallpaper preview, explicitly enable it, then switch away and back to confirm static image redraws.
- [ ] Check memory behaviour with large foreground/background images and confirm errors do not crash the app.
- [ ] Confirm the app works offline and no photos are uploaded.

## Phase 3 phone testing checklist
- [ ] GitHub Actions build succeeds; install the debug APK.
- [ ] Create → Quick Mode → Choose Photo opens Android Photo Picker.
- [ ] Select a photo and confirm the original still exists unchanged in the gallery.
- [ ] Select the same photo again and confirm no second original copy is created.
- [ ] With a clear person photo, Auto Cutout produces a transparent preview and keeps hair/edge transitions reasonably smooth.
- [ ] Turn off internet before testing and confirm bundled person segmentation still works.
- [ ] Select a car/animal/anime/object photo and use Manual Mask; erase and restore both work.
- [ ] Change brush size; test soft edges, undo, redo, reset, pinch zoom and pan.
- [ ] Cancel segmentation and confirm the screen returns to an idle state.
- [ ] Save and confirm `mask.png`, `foreground.png` and `metadata.properties` exist in app-private storage through app behaviour (not a public gallery folder).
- [ ] Reopen the same original and confirm cached cutout loads without repeating automatic segmentation.
- [ ] Library → My cutouts displays saved foreground previews.
- [ ] Try a large photo and confirm the app remains responsive and shows a readable error rather than closing if memory is insufficient.
- [ ] Confirm Settings privacy text matches the actual on-device processing behaviour.

## Known limitations
- **Written, untested:** no Android SDK, Gradle executable or project Gradle wrapper is available in the authoring environment, so this ZIP has not been compiled, installed or device-tested. Run the repository GitHub Actions workflow and fix any Kotlin/Gradle errors before relying on the APK.
- ML Kit Selfie Segmentation is beta and intended for people. It is not a general object segmenter; use the manual mask for other subjects until a compatible model is added.
- Cancellation stops the app coroutine/UI operation; the underlying ML Kit task may finish internally because its Task API does not expose a cancellation handle.
- The editor mask is preview resolution. To limit memory use, the saved foreground is currently capped at a 4096 px long side; the untouched original remains available. Full original-resolution tiled export is future optimization work.
- Automatic cutout cache is created at preview resolution first; pressing Save writes the higher-resolution foreground and mask.
- `My cutouts` is a simple file-backed list, not a Room database. Project management arrives in Phase 7.
- Phase 4–6 Studio renderer, MediaStore/document-picker export, wallpaper application and `WallpaperService` are all **written but untested**. OEM-specific wallpaper behaviour must be verified on a physical phone.
- Lock-screen wallpaper support varies by phone maker. No release signing is configured.
