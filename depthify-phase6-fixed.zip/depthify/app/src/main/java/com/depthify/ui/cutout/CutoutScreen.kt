package com.depthify.ui.cutout

import android.graphics.Bitmap
import android.graphics.Canvas as NativeCanvas
import android.graphics.Paint as NativePaint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.depthify.ui.components.GhostButton
import com.depthify.ui.components.GoldButton
import com.depthify.ui.components.GlassCard
import com.depthify.ui.components.ScreenContainer
import com.depthify.ui.theme.DepthAccent
import com.depthify.ui.theme.DepthBackground
import com.depthify.ui.theme.DepthSurfaceAlt
import com.depthify.ui.theme.DepthTextPrimary
import com.depthify.ui.theme.DepthTextSecondary
import kotlinx.coroutines.launch
import kotlin.math.min

@Composable
fun CutoutScreen(onBack: () -> Unit, vm: CutoutViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) vm.choose(uri) }
    var eraseMode by remember { mutableStateOf(true) }
    var brushSize by remember { mutableFloatStateOf(36f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    val undo = remember { mutableStateListOf<Bitmap>() }
    val redo = remember { mutableStateListOf<Bitmap>() }
    val scope = rememberCoroutineScope()

    ScreenContainer(title = "Cutout", subtitle = "Create a transparent foreground layer") {
        if (state.preview == null && !state.busy) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Choose one photo", color = DepthTextPrimary, style = MaterialTheme.typography.titleLarge)
                Text("The original is copied unchanged into private app storage. Selecting the same image again reuses that copy.", color = DepthTextSecondary)
                GoldButton("Choose Photo", { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, Modifier.fillMaxWidth())
            }
        }
        if (state.busy) {
            GlassCard(Modifier.fillMaxWidth()) {
                CircularProgressIndicator(color = DepthAccent)
                Text(state.progress, color = DepthTextSecondary)
                GhostButton("Cancel", vm::cancelWork, Modifier.fillMaxWidth())
            }
        }
        state.error?.let { Text(it, color = Color(0xFFFF796F)) }
        if (state.preview != null && state.mask == null && !state.busy) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Choose a cutout method", color = DepthTextPrimary, style = MaterialTheme.typography.titleLarge)
                Text("Automatic mode is designed for people. Use Manual Mask for cars, aircraft, animals, anime and objects.", color = DepthTextSecondary)
                GoldButton("Auto Cutout · Person", vm::runPersonSegmentation, Modifier.fillMaxWidth(), Icons.Filled.AutoFixHigh)
                GhostButton("Manual Mask", vm::startManualMask, Modifier.fillMaxWidth(), Icons.Filled.Brush)
            }
        }
        if (state.foreground != null && state.mask != null) {
            Text(if (state.manualMode) "Manual mask" else "Foreground preview", color = DepthTextPrimary, style = MaterialTheme.typography.titleMedium)
            Text("Pinch to zoom · Drag with one finger to paint", color = DepthTextSecondary, style = MaterialTheme.typography.bodySmall)
            val mask = state.mask!!
            val preview = state.foreground!!
            val latestMask by rememberUpdatedState(mask)
            val latestEraseMode by rememberUpdatedState(eraseMode)
            val latestBrushSize by rememberUpdatedState(brushSize)
            val latestZoom by rememberUpdatedState(zoom)
            val latestPanX by rememberUpdatedState(panX)
            val latestPanY by rememberUpdatedState(panY)
            val transformState = rememberTransformableState { zoomChange, panChange, _ ->
                zoom = (zoom * zoomChange).coerceIn(1f, 5f)
                panX += panChange.x
                panY += panChange.y
            }
            Box(Modifier.fillMaxWidth().height(390.dp).clip(RoundedCornerShape(22.dp)).background(DepthBackground), contentAlignment = Alignment.Center) {
                Canvas(
                    Modifier.fillMaxSize()
                        .graphicsLayer(scaleX = zoom, scaleY = zoom, translationX = panX, translationY = panY)
                        .transformable(transformState)
                        .pointerInput(state.originalName) {
                            detectDragGestures(
                                onDragStart = {
                                    if (undo.size >= 12) undo.removeAt(0)
                                    undo.add(latestMask.copy(Bitmap.Config.ARGB_8888, true))
                                    redo.clear()
                                },
                                onDrag = { change, _ ->
                                    val activeMask = latestMask
                                    val fittedScale = min(size.width.toFloat() / activeMask.width, size.height.toFloat() / activeMask.height)
                                    val drawW = activeMask.width * fittedScale
                                    val drawH = activeMask.height * fittedScale
                                    val left = (size.width - drawW) / 2f
                                    val top = (size.height - drawH) / 2f
                                    val x = ((change.position.x - latestPanX - left) / (fittedScale * latestZoom)).coerceIn(0f, activeMask.width.toFloat())
                                    val y = ((change.position.y - latestPanY - top) / (fittedScale * latestZoom)).coerceIn(0f, activeMask.height.toFloat())
                                    val mutable = activeMask
                                    val nativeCanvas = NativeCanvas(mutable)
                                    val radius = latestBrushSize * size.width / 360f / (fittedScale * latestZoom)
                                    val paint = NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply {
                                        shader = RadialGradient(x, y, radius, intArrayOf(android.graphics.Color.WHITE, android.graphics.Color.WHITE, android.graphics.Color.TRANSPARENT), floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP)
                                        xfermode = PorterDuffXfermode(if (latestEraseMode) PorterDuff.Mode.DST_OUT else PorterDuff.Mode.SRC_OVER)
                                    }
                                    nativeCanvas.drawCircle(x, y, radius, paint)
                                    vm.updateMask(mutable.copy(Bitmap.Config.ARGB_8888, true))
                                    change.consume()
                                }
                            )
                        }
                ) {
                    val cell = 18.dp.toPx()
                    var y = 0f
                    while (y < size.height) {
                        var x = 0f
                        while (x < size.width) {
                            drawRect(if (((x / cell).toInt() + (y / cell).toInt()) % 2 == 0) Color(0xFF353535) else Color(0xFF222222), androidx.compose.ui.geometry.Offset(x, y), androidx.compose.ui.geometry.Size(cell, cell))
                            x += cell
                        }
                        y += cell
                    }
                    val bitmap = preview.asImageBitmap()
                    val scale = min(size.width / bitmap.width, size.height / bitmap.height)
                    val w = bitmap.width * scale
                    val h = bitmap.height * scale
                    drawImage(bitmap, dstOffset = androidx.compose.ui.unit.IntOffset(((size.width - w) / 2).toInt(), ((size.height - h) / 2).toInt()), dstSize = IntSize(w.toInt(), h.toInt()))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                GhostButton(if (eraseMode) "Erase" else "Restore", { eraseMode = !eraseMode }, Modifier.weight(1f), Icons.Filled.Brush)
                GhostButton("Undo", {
                    if (undo.isNotEmpty()) { redo.add(mask.copy(Bitmap.Config.ARGB_8888, true)); vm.updateMask(undo.removeAt(undo.lastIndex)) }
                }, Modifier.weight(1f), Icons.Filled.Undo)
                GhostButton("Redo", {
                    if (redo.isNotEmpty()) { undo.add(mask.copy(Bitmap.Config.ARGB_8888, true)); vm.updateMask(redo.removeAt(redo.lastIndex)) }
                }, Modifier.weight(1f), Icons.Filled.Redo)
            }
            Text("Brush size", color = DepthTextSecondary)
            Slider(value = brushSize, onValueChange = { brushSize = it }, valueRange = 8f..100f)
            GhostButton("Switch to Manual Mask", {
                undo.clear(); redo.clear()
                vm.startManualMask()
            }, Modifier.fillMaxWidth(), Icons.Filled.Brush)
            GhostButton("Reset to automatic mask", {
                undo.clear(); redo.clear(); zoom = 1f; panX = 0f; panY = 0f
                vm.runPersonSegmentation()
            }, Modifier.fillMaxWidth(), Icons.Filled.RestartAlt)
            GoldButton(if (state.saved) "Saved · Update Cutout" else "Save Transparent PNG", vm::save, Modifier.fillMaxWidth(), Icons.Filled.Check, enabled = !state.busy)
            if (state.saved) Text("Saved privately. Phase 4 can load this foreground layer.", color = DepthAccent)
        }
        GhostButton("Back", onBack, Modifier.fillMaxWidth(), Icons.Filled.ArrowBack)
    }
}
