package com.depthify.core.image

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Saves a bitmap into Pictures/DEPTHIFY using MediaStore (no permission on Android 10+). */
object GallerySaver {

    const val FOLDER = "DEPTHIFY"

    fun save(context: Context, bitmap: Bitmap, baseName: String): Result<Unit> = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveModern(context, bitmap, baseName)
        } else {
            saveLegacy(context, bitmap, baseName)
        }
    }

    private fun saveModern(context: Context, bitmap: Bitmap, baseName: String) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$baseName.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create the image in your gallery.")
        try {
            val stream = resolver.openOutputStream(uri) ?: error("Could not open the gallery file.")
            stream.use { out ->
                check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "Could not encode the image." }
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(context: Context, bitmap: Bitmap, baseName: String) {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), FOLDER)
        check(dir.exists() || dir.mkdirs()) { "Could not create the DEPTHIFY folder." }
        val file = File(dir, "$baseName.png")
        file.outputStream().use { out ->
            check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "Could not encode the image." }
        }
        MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/png"), null)
    }
}
