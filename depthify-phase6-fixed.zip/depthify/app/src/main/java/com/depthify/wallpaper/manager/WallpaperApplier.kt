package com.depthify.wallpaper.manager

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap

enum class WallpaperTarget { Home, Lock, Both }

/** Sets a bitmap as the system wallpaper. Blocking: call from a background dispatcher. */
object WallpaperApplier {

    fun apply(context: Context, bitmap: Bitmap, target: WallpaperTarget): Result<Unit> = runCatching {
        val manager = WallpaperManager.getInstance(context)
        check(manager.isWallpaperSupported) { "This device does not support changing the wallpaper." }
        check(manager.isSetWallpaperAllowed) { "Changing the wallpaper is blocked on this device." }
        val flags = when (target) {
            WallpaperTarget.Home -> WallpaperManager.FLAG_SYSTEM
            WallpaperTarget.Lock -> WallpaperManager.FLAG_LOCK
            WallpaperTarget.Both -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        }
        manager.setBitmap(bitmap, null, true, flags)
        Unit
    }
}
