package com.depthify.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.depthify.ui.explore.ExploreScreen
import com.depthify.ui.explore.PreviewScreen
import com.depthify.ui.gallery.GalleryViewModel
import com.depthify.ui.gallery.LocalWallpaperLoader
import com.depthify.ui.home.HomeScreen
import com.depthify.ui.library.LibraryScreen
import com.depthify.ui.settings.SettingsScreen
import com.depthify.ui.studio.CreateScreen
import com.depthify.ui.studio.StudioScreen
import com.depthify.ui.cutout.CutoutScreen
import com.depthify.ui.theme.DepthAccent
import com.depthify.ui.theme.DepthBackground
import com.depthify.ui.theme.DepthSurface
import com.depthify.ui.theme.DepthTextSecondary

@Composable
fun MainScaffold(onReplayOnboarding: () -> Unit) {
    // Activity-scoped, so Home, Explore, Library and Preview share one instance.
    val galleryViewModel: GalleryViewModel = viewModel()

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val goTo: (MainTab) -> Unit = { tab ->
        navController.navigate(tab.route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    val openPreview: () -> Unit = {
        navController.navigate(PREVIEW_ROUTE) { launchSingleTop = true }
    }

    CompositionLocalProvider(LocalWallpaperLoader provides galleryViewModel.loader) {
        Scaffold(
            containerColor = DepthBackground,
            contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
            bottomBar = {
                if (currentRoute != PREVIEW_ROUTE && currentRoute != "cutout" && currentRoute != "studio") {
                    NavigationBar(containerColor = DepthSurface, tonalElevation = 0.dp) {
                        MainTab.entries.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { if (!selected) goTo(tab) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.icon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = DepthAccent,
                                    indicatorColor = DepthAccent,
                                    unselectedIconColor = DepthTextSecondary,
                                    unselectedTextColor = DepthTextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = MainTab.Home.route,
                modifier = Modifier.padding(padding),
                enterTransition = { fadeIn(tween(200)) },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(200)) },
                popExitTransition = { fadeOut(tween(200)) }
            ) {
                composable(MainTab.Home.route) {
                    HomeScreen(
                        vm = galleryViewModel,
                        onOpenCreate = { goTo(MainTab.Create) },
                        onOpenCategory = { category ->
                            galleryViewModel.selectCategory(category)
                            goTo(MainTab.Explore)
                        },
                        onOpenPreview = openPreview
                    )
                }
                composable(MainTab.Explore.route) {
                    ExploreScreen(vm = galleryViewModel, onOpenPreview = openPreview)
                }
                composable(MainTab.Create.route) {
                    CreateScreen(
                        onQuickMode = { navController.navigate("cutout") },
                        onOpenStudio = { navController.navigate("studio") }
                    )
                }
                composable("studio") { StudioScreen(onBack = { navController.popBackStack() }) }
                composable("cutout") {
                    CutoutScreen(onBack = { navController.popBackStack() })
                }
                composable(MainTab.Library.route) {
                    LibraryScreen(vm = galleryViewModel, onOpenPreview = openPreview)
                }
                composable(MainTab.Settings.route) {
                    SettingsScreen(onReplayOnboarding = onReplayOnboarding)
                }
                composable(PREVIEW_ROUTE) {
                    PreviewScreen(vm = galleryViewModel, onBack = { navController.popBackStack() })
                }
            }
        }
    }
}
