package com.depthify.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.depthify.core.models.WallpaperCategory
import com.depthify.core.models.WallpaperItem
import com.depthify.data.repository.WallpaperCatalog
import com.depthify.ui.components.CategoryChip
import com.depthify.ui.components.DepthifyWordmark
import com.depthify.ui.components.EmptyState
import com.depthify.ui.components.GhostButton
import com.depthify.ui.components.GoldButton
import com.depthify.ui.components.PlaceholderCard
import com.depthify.ui.components.SectionHeader
import com.depthify.ui.gallery.GalleryViewModel
import com.depthify.ui.gallery.WallpaperThumb
import com.depthify.ui.theme.DepthAccent
import com.depthify.ui.theme.DepthOutline
import com.depthify.ui.theme.DepthSurface
import com.depthify.ui.theme.DepthTextPrimary
import com.depthify.ui.theme.DepthTextSecondary

@Composable
fun HomeScreen(
    vm: GalleryViewModel,
    onOpenCreate: () -> Unit,
    onOpenCategory: (WallpaperCategory) -> Unit,
    onOpenPreview: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val imported by vm.imported.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val results = remember(query, imported) { WallpaperCatalog.search(query, imported) }

    fun open(list: List<WallpaperItem>, index: Int) {
        vm.openPreview(list, index)
        onOpenPreview()
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Column(
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                DepthifyWordmark()
                Text(
                    "YOUR WALLPAPER. YOUR DEPTH.",
                    style = MaterialTheme.typography.labelMedium,
                    color = DepthTextSecondary
                )
            }
            SearchField(value = query, onValueChange = { query = it })
        }

        if (query.isBlank()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    GoldButton("Quick Create", onOpenCreate, Modifier.weight(1f), icon = Icons.Filled.Bolt)
                    GhostButton("Depth Studio", onOpenCreate, Modifier.weight(1f), icon = Icons.Filled.Layers)
                }

                SectionHeader("Categories")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(WallpaperCategory.entries.toList()) { category ->
                        CategoryChip(
                            label = category.label,
                            selected = false,
                            onClick = { onOpenCategory(category) }
                        )
                    }
                }

                SectionHeader("Featured wallpapers")
                ThumbRow(WallpaperCatalog.featured, favorites) { index -> open(WallpaperCatalog.featured, index) }

                SectionHeader("Recently edited")
                PlaceholderCard(
                    icon = Icons.Filled.History,
                    title = "Nothing edited yet",
                    message = "Projects you edit will show up here.",
                    badge = "Phase 7"
                )

                SectionHeader("Trending collection")
                ThumbRow(WallpaperCatalog.trending, favorites) { index -> open(WallpaperCatalog.trending, index) }
            }
        } else if (results.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(20.dp)) {
                EmptyState(
                    icon = Icons.Filled.SearchOff,
                    title = "No matches",
                    message = "Try a category such as Space or Nature, or a word from a wallpaper title."
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(results, key = { _, entry -> entry.id }) { index, entry ->
                    WallpaperThumb(
                        item = entry,
                        isFavorite = entry.id in favorites,
                        onClick = { open(results, index) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ThumbRow(items: List<WallpaperItem>, favorites: Set<String>, onClick: (Int) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        itemsIndexed(items, key = { _, entry -> entry.id }) { index, entry ->
            WallpaperThumb(
                item = entry,
                isFavorite = entry.id in favorites,
                onClick = { onClick(index) },
                modifier = Modifier.width(140.dp)
            )
        }
    }
}

@Composable
private fun SearchField(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(50),
        placeholder = { Text("Search wallpapers", color = DepthTextSecondary) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = DepthTextSecondary) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onValueChange("") }) {
                    Icon(Icons.Filled.Close, contentDescription = "Clear search", tint = DepthTextSecondary)
                }
            }
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = DepthTextPrimary,
            unfocusedTextColor = DepthTextPrimary,
            focusedContainerColor = DepthSurface,
            unfocusedContainerColor = DepthSurface,
            cursorColor = DepthAccent,
            focusedBorderColor = DepthAccent,
            unfocusedBorderColor = DepthOutline
        )
    )
}
