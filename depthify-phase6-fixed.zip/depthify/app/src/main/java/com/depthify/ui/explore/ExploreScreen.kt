package com.depthify.ui.explore

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.depthify.core.models.WallpaperCategory
import com.depthify.data.repository.WallpaperCatalog
import com.depthify.ui.components.CategoryChip
import com.depthify.ui.components.EmptyState
import com.depthify.ui.components.GlassCard
import com.depthify.ui.gallery.GalleryViewModel
import com.depthify.ui.gallery.ImportSection
import com.depthify.ui.gallery.WallpaperThumb
import com.depthify.ui.theme.DepthTextPrimary
import com.depthify.ui.theme.DepthTextSecondary

@Composable
fun ExploreScreen(vm: GalleryViewModel, onOpenPreview: () -> Unit) {
    val category by vm.exploreCategory.collectAsStateWithLifecycle()
    val imported by vm.imported.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val importState by vm.importState.collectAsStateWithLifecycle()

    val visible = if (category == WallpaperCategory.Custom) imported else WallpaperCatalog.byCategory(category)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importPhoto(uri)
    }
    val launchPicker = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    LaunchedEffect(category) { vm.dismissImportError() }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Explore", style = MaterialTheme.typography.headlineLarge, color = DepthTextPrimary)
                Text(
                    "Browse wallpapers by category",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DepthTextSecondary
                )
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(WallpaperCategory.entries.toList()) { entry ->
                    CategoryChip(
                        label = entry.label,
                        selected = entry == category,
                        onClick = { vm.selectCategory(entry) }
                    )
                }
            }
        }

        if (category == WallpaperCategory.Custom) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                ImportSection(state = importState, onImport = { launchPicker() })
            }
        }

        if (visible.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                GlassCard(Modifier.fillMaxWidth()) {
                    EmptyState(
                        icon = Icons.Filled.Image,
                        title = if (category == WallpaperCategory.Custom) "No photos yet" else "Nothing here yet",
                        message = if (category == WallpaperCategory.Custom) {
                            "Import a photo from your gallery. DEPTHIFY keeps an untouched copy inside the app."
                        } else {
                            "This category is empty."
                        }
                    )
                }
            }
        } else {
            itemsIndexed(visible, key = { _, entry -> entry.id }) { index, entry ->
                WallpaperThumb(
                    item = entry,
                    isFavorite = entry.id in favorites,
                    onClick = {
                        vm.openPreview(visible, index)
                        onOpenPreview()
                    }
                )
            }
        }
    }
}
