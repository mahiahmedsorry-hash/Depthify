package com.depthify.ui.gallery

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.depthify.core.models.WallpaperItem
import com.depthify.engine.rendering.WallpaperLoader
import com.depthify.ui.components.ErrorState
import com.depthify.ui.components.GoldButton
import com.depthify.ui.components.LoadingIndicator
import com.depthify.ui.theme.DepthAccent
import com.depthify.ui.theme.DepthSurfaceAlt
import com.depthify.ui.theme.DepthTextSecondary

val LocalWallpaperLoader = staticCompositionLocalOf<WallpaperLoader> {
    error("WallpaperLoader was not provided")
}

sealed interface BitmapState {
    object Loading : BitmapState
    class Ready(val image: ImageBitmap) : BitmapState
    object Failed : BitmapState
}

/** Loads a wallpaper off the main thread; shows the cached bitmap instantly when there is one. */
@Composable
fun rememberWallpaperBitmap(item: WallpaperItem, width: Int, height: Int): BitmapState {
    val loader = LocalWallpaperLoader.current
    val state by produceState<BitmapState>(
        initialValue = loader.cached(item, width, height)
            ?.let { BitmapState.Ready(it.asImageBitmap()) }
            ?: BitmapState.Loading,
        key1 = "${item.id}@${width}x$height"
    ) {
        if (value is BitmapState.Ready) return@produceState
        val bitmap = loader.load(item, width, height)
        value = if (bitmap != null) BitmapState.Ready(bitmap.asImageBitmap()) else BitmapState.Failed
    }
    return state
}

@Composable
fun WallpaperThumb(
    item: WallpaperItem,
    isFavorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val loader = LocalWallpaperLoader.current
    val state = rememberWallpaperBitmap(item, loader.thumbWidth, loader.thumbHeight)
    Box(
        modifier = modifier
            .aspectRatio(loader.thumbWidth.toFloat() / loader.thumbHeight)
            .clip(RoundedCornerShape(20.dp))
            .background(DepthSurfaceAlt)
            .clickable(onClick = onClick)
    ) {
        when (state) {
            is BitmapState.Ready -> Image(
                bitmap = state.image,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            BitmapState.Loading -> CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center).size(24.dp),
                color = DepthAccent,
                strokeWidth = 2.dp
            )
            BitmapState.Failed -> Icon(
                Icons.Filled.BrokenImage,
                contentDescription = "Could not load",
                tint = DepthTextSecondary,
                modifier = Modifier.align(Alignment.Center).size(28.dp)
            )
        }
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Text(
                item.title,
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (isFavorite) {
            Icon(
                Icons.Filled.Favorite,
                contentDescription = "Favorite",
                tint = DepthAccent,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(18.dp)
            )
        }
    }
}

/** Import button plus loading / error feedback, shared by Explore (Custom) and Library. */
@Composable
fun ImportSection(state: ImportState, onImport: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (state) {
            ImportState.Loading -> LoadingIndicator(message = "Importing your photo…")
            is ImportState.Error -> ErrorState(message = state.message, onRetry = onImport)
            ImportState.Idle -> GoldButton(
                text = "Import a photo",
                onClick = onImport,
                modifier = Modifier.fillMaxWidth(),
                icon = Icons.Filled.AddPhotoAlternate
            )
        }
    }
}
