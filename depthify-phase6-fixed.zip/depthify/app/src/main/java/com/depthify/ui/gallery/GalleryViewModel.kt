package com.depthify.ui.gallery

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.depthify.core.image.GallerySaver
import com.depthify.core.models.WallpaperCategory
import com.depthify.core.models.WallpaperItem
import com.depthify.core.models.WallpaperSource
import com.depthify.data.preferences.UserPreferences
import com.depthify.data.repository.ImportedPhotoStore
import com.depthify.engine.rendering.WallpaperLoader
import com.depthify.wallpaper.manager.WallpaperApplier
import com.depthify.wallpaper.manager.WallpaperTarget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface ImportState {
    object Idle : ImportState
    object Loading : ImportState
    data class Error(val message: String) : ImportState
}

/** One shared instance (activity scope) for Home, Explore, Library and the preview screen. */
class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val appContext: Context = app.applicationContext
    private val prefs = UserPreferences(appContext)
    private val store = ImportedPhotoStore(appContext)

    val loader = WallpaperLoader(appContext, store)

    val favorites: StateFlow<Set<String>> =
        prefs.favorites.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    private val _imported = MutableStateFlow<List<WallpaperItem>>(emptyList())
    val imported: StateFlow<List<WallpaperItem>> = _imported.asStateFlow()

    private val _importState = MutableStateFlow<ImportState>(ImportState.Idle)
    val importState: StateFlow<ImportState> = _importState.asStateFlow()

    private val _exploreCategory = MutableStateFlow(WallpaperCategory.Anime)
    val exploreCategory: StateFlow<WallpaperCategory> = _exploreCategory.asStateFlow()

    /** The list shown by the fullscreen preview, set right before navigating to it. */
    var previewItems: List<WallpaperItem> = emptyList()
        private set
    var previewStart: Int = 0
        private set

    init {
        refreshImported()
    }

    fun openPreview(items: List<WallpaperItem>, startIndex: Int) {
        previewItems = items
        previewStart = startIndex
    }

    fun selectCategory(category: WallpaperCategory) {
        _exploreCategory.value = category
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch { prefs.toggleFavorite(id) }
    }

    private fun refreshImported() {
        viewModelScope.launch {
            _imported.value = withContext(Dispatchers.IO) { store.list() }
        }
    }

    fun importPhoto(uri: Uri) {
        if (_importState.value == ImportState.Loading) return
        viewModelScope.launch {
            _importState.value = ImportState.Loading
            val result = withContext(Dispatchers.IO) {
                runCatching { store.importFrom(appContext.contentResolver, uri) }
            }
            result
                .onSuccess {
                    _imported.value = withContext(Dispatchers.IO) { store.list() }
                    _importState.value = ImportState.Idle
                }
                .onFailure { error ->
                    _importState.value = ImportState.Error(
                        if (error is OutOfMemoryError) {
                            "This photo is too large for your device's memory."
                        } else {
                            error.message ?: "Could not import this photo."
                        }
                    )
                }
        }
    }

    fun dismissImportError() {
        if (_importState.value is ImportState.Error) _importState.value = ImportState.Idle
    }

    fun deleteImported(item: WallpaperItem) {
        val source = item.source as? WallpaperSource.Imported ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.delete(source.fileName) }
            prefs.removeFavorite(item.id)
            _imported.value = withContext(Dispatchers.IO) { store.list() }
        }
    }

    suspend fun applyWallpaper(item: WallpaperItem, target: WallpaperTarget): Result<Unit> =
        withContext(Dispatchers.Default) {
            runCatching {
                val bitmap = loader.load(item, loader.screenWidth, loader.screenHeight, useCache = false)
                    ?: error("Could not prepare this wallpaper. The photo may be too large for your device.")
                try {
                    WallpaperApplier.apply(appContext, bitmap, target).getOrThrow()
                } finally {
                    bitmap.recycle()
                }
            }
        }

    suspend fun saveToGallery(item: WallpaperItem): Result<Unit> =
        withContext(Dispatchers.Default) {
            runCatching {
                val bitmap = loader.load(item, loader.screenWidth, loader.screenHeight, useCache = false)
                    ?: error("Could not prepare this wallpaper.")
                try {
                    val name = "DEPTHIFY_${item.id.substringAfter(':')}_${System.currentTimeMillis()}"
                    GallerySaver.save(appContext, bitmap, name).getOrThrow()
                } finally {
                    bitmap.recycle()
                }
            }
        }
}
