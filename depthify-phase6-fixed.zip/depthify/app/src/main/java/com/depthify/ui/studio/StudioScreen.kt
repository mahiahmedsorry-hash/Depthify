package com.depthify.ui.studio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.depthify.data.repository.CutoutStore
import com.depthify.engine.rendering.StudioRenderer
import com.depthify.engine.rendering.StudioRenderOptions
import com.depthify.engine.rendering.StudioTextLayer
import com.depthify.ui.components.GoldButton
import com.depthify.ui.theme.*
import com.depthify.wallpaper.manager.WallpaperApplier
import com.depthify.wallpaper.manager.WallpaperTarget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private data class StudioCutout(val key: String, val title: String, val file: File)

@Composable
fun StudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cutouts = remember { CutoutStore(context).list().map { StudioCutout(it.key, it.originalName, it.foregroundFile) } }
    var selected by remember { mutableStateOf(cutouts.firstOrNull()) }
    var backgroundFile by remember { mutableStateOf<File?>(null) }
    var backgroundColor by remember { mutableIntStateOf(AndroidColor.BLACK) }
    var backgroundVisible by remember { mutableStateOf(true) }
    var foregroundVisible by remember { mutableStateOf(true) }
    var foregroundLocked by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableFloatStateOf(0f) }
    var x by remember { mutableFloatStateOf(0.5f) }
    var y by remember { mutableFloatStateOf(0.5f) }
    var bgBrightness by remember { mutableFloatStateOf(1f) }
    var fgBrightness by remember { mutableFloatStateOf(1f) }
    var blur by remember { mutableFloatStateOf(0f) }
    var textLayers by remember { mutableStateOf(listOf<StudioTextLayer>()) }
    var activeTextId by remember { mutableStateOf<Long?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var pendingWallpaperTarget by remember { mutableStateOf<WallpaperTarget?>(null) }
    var busy by remember { mutableStateOf(false) }
    var outputBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var resolution by remember { mutableStateOf("1080p") }
    var format by remember { mutableStateOf("PNG") }
    var exportFile by remember { mutableStateOf<File?>(null) }
    DisposableEffect(outputBitmap) {
        val current = outputBitmap
        onDispose { if (current != null && !current.isRecycled) current.recycle() }
    }

    val backgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val folder = File(context.filesDir, "studio/backgrounds").apply { mkdirs() }
                    val target = File(folder, "background_${System.currentTimeMillis()}.img")
                    context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                        ?: error("Unable to read selected image")
                    target
                }
            }.onSuccess { backgroundFile = it; status = "Background imported privately." }
                .onFailure { status = it.message ?: "Background import failed." }
        }
    }
    val legacySaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        val file = exportFile
        if (result.resultCode == android.app.Activity.RESULT_OK && uri != null && file != null) {
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                            ?: error("Unable to write selected destination")
                    }
                }.onSuccess { status = "Wallpaper saved to the selected location." }
                    .onFailure { status = it.message ?: "Save failed." }
            }
        }
    }

    fun renderPreview() {
        val item = selected ?: return
        scope.launch {
            busy = true
            runCatching {
                withContext(Dispatchers.Default) {
                    StudioRenderer.render(item.file, backgroundFile, 720, 1280,
                        StudioRenderOptions(backgroundColor, bgBrightness, blur, fgBrightness, scale, x, y, rotation, foregroundVisible, backgroundVisible), textLayers)
                }
            }.onSuccess { rendered -> outputBitmap = rendered; status = null }
                .onFailure { status = it.message ?: "Preview could not be rendered." }
            busy = false
        }
    }

    LaunchedEffect(selected, backgroundFile, backgroundColor, backgroundVisible, foregroundVisible, scale, rotation, x, y, bgBrightness, fgBrightness, blur, textLayers) {
        if (selected != null) renderPreview()
    }

    Column(Modifier.fillMaxSize().background(DepthBackground).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = DepthTextPrimary) }
            Column(Modifier.weight(1f)) { Text("Depth Studio", color = DepthTextPrimary, fontSize = 22.sp); Text("Compose your depth wallpaper", color = DepthTextSecondary, fontSize = 12.sp) }
            IconButton(onClick = { renderPreview() }) { Icon(Icons.Default.FileDownload, "Refresh preview", tint = DepthAccent) }
        }
        if (cutouts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("No saved cutouts yet", color = DepthTextPrimary, fontSize = 20.sp)
                    Text("Create and save a cutout first, then return to Studio.", color = DepthTextSecondary)
                    GoldButton("Back", onBack)
                }
            }
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(cutouts) { item ->
                    FilterChip(selected = selected?.key == item.key, onClick = { selected = item }, label = { Text(item.title.take(18)) })
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF171717), RoundedCornerShape(20.dp)).border(1.dp, DepthOutline, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                val bitmap = outputBitmap
                if (bitmap != null) {
                    Canvas(Modifier.fillMaxSize().padding(10.dp).pointerInput(foregroundLocked, activeTextId, textLayers) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            val activeLayer = textLayers.firstOrNull { it.id == activeTextId }
                            if (activeLayer != null && !activeLayer.locked) {
                                textLayers = textLayers.map { layer -> if (layer.id == activeLayer.id) layer.copy(x = (layer.x + drag.x / size.width).coerceIn(0f, 1f), y = (layer.y + drag.y / size.height).coerceIn(0f, 1f)) else layer }
                            } else if (!foregroundLocked) {
                                x = (x + drag.x / size.width).coerceIn(0f, 1f); y = (y + drag.y / size.height).coerceIn(0f, 1f)
                            }
                        }
                    }) {
                        val image = bitmap.asImageBitmap()
                        val fit = minOf(size.width / image.width, size.height / image.height)
                        val w = image.width * fit; val h = image.height * fit
                        drawImage(image, dstOffset = androidx.compose.ui.unit.IntOffset(((size.width-w)/2).toInt(), ((size.height-h)/2).toInt()), dstSize = androidx.compose.ui.unit.IntSize(w.toInt(), h.toInt()))
                    }
                } else CircularProgressIndicator(color = DepthAccent)
                if (busy) CircularProgressIndicator(Modifier.align(Alignment.TopEnd).padding(12.dp), color = DepthAccent)
            }
            Text("LAYERS", color = DepthAccent, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                AssistChip(onClick = { backgroundVisible = !backgroundVisible }, label = { Text(if (backgroundVisible) "Background: visible" else "Background: hidden") }, leadingIcon = { Icon(if (backgroundVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null) })
                AssistChip(onClick = { foregroundVisible = !foregroundVisible }, label = { Text(if (foregroundVisible) "Subject: visible" else "Subject: hidden") }, leadingIcon = { Icon(if (foregroundVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null) })
                AssistChip(onClick = { foregroundLocked = !foregroundLocked }, label = { Text(if (foregroundLocked) "Locked" else "Unlocked") }, leadingIcon = { Icon(if (foregroundLocked) Icons.Default.Lock else Icons.Default.LockOpen, null) })
            }
            Column(Modifier.weight(1.1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("BACKGROUND", color = DepthAccent, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { backgroundPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Import") }
                    OutlinedButton(onClick = { backgroundFile = null; backgroundColor = AndroidColor.rgb(12, 18, 30) }) { Text("Deep blue") }
                    OutlinedButton(onClick = { backgroundFile = null; backgroundColor = AndroidColor.BLACK }) { Text("Black") }
                }
                SliderRow("Background brightness", bgBrightness, 0.25f..1.5f) { bgBrightness = it }
                SliderRow("Background blur", blur, 0f..24f) { blur = it }
                Text("SUBJECT", color = DepthAccent, fontSize = 11.sp)
                SliderRow("Scale", scale, 0.3f..2.5f) { scale = it }
                SliderRow("Rotation", rotation, -180f..180f) { rotation = it }
                SliderRow("Brightness", fgBrightness, 0.25f..1.5f) { fgBrightness = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { x = 0.5f; y = 0.5f; scale = 1f; rotation = 0f }) { Text("Center / Reset") }
                    OutlinedButton(onClick = { x = 0.5f; y = 0.72f }) { Text("Bottom") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("TEXT LAYERS", color = DepthAccent, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        val new = StudioTextLayer(id = System.nanoTime(), text = "YOUR TEXT", y = 0.2f)
                        textLayers = textLayers + new; activeTextId = new.id
                    }) { Icon(Icons.Default.Add, "Add text", tint = DepthAccent) }
                }
                textLayers.forEach { layer ->
                    Row(Modifier.fillMaxWidth().background(DepthSurface, RoundedCornerShape(12.dp)).clickable { activeTextId = layer.id }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(layer.text, color = DepthTextPrimary, modifier = Modifier.weight(1f), maxLines = 1)
                        IconButton(onClick = { textLayers = textLayers.map { if (it.id == layer.id) it.copy(visible = !it.visible) else it } }) { Icon(if (layer.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null, tint = DepthAccent) }
                        IconButton(onClick = { textLayers = textLayers.map { if (it.id == layer.id) it.copy(locked = !it.locked) else it } }) { Icon(if (layer.locked) Icons.Default.Lock else Icons.Default.LockOpen, null, tint = DepthAccent) }
                        IconButton(onClick = { val index = textLayers.indexOfFirst { it.id == layer.id }; if (index > 0) textLayers = textLayers.toMutableList().also { val item = it.removeAt(index); it.add(index - 1, item) } }) { Icon(Icons.Default.ArrowUpward, null, tint = DepthAccent) }
                        IconButton(onClick = { val index = textLayers.indexOfFirst { it.id == layer.id }; if (index in 0 until textLayers.lastIndex) textLayers = textLayers.toMutableList().also { val item = it.removeAt(index); it.add(index + 1, item) } }) { Icon(Icons.Default.ArrowDownward, null, tint = DepthAccent) }
                        IconButton(onClick = { textLayers = textLayers.filterNot { it.id == layer.id }; if (activeTextId == layer.id) activeTextId = null }) { Icon(Icons.Default.Delete, null, tint = DepthError) }
                    }
                }
                val active = textLayers.firstOrNull { it.id == activeTextId }
                if (active != null) {
                    BasicTextField(value = active.text, onValueChange = { v -> textLayers = textLayers.map { if (it.id == active.id) it.copy(text = v) else it } }, textStyle = TextStyle(color = DepthTextPrimary, fontSize = 16.sp), modifier = Modifier.fillMaxWidth().background(DepthSurface, RoundedCornerShape(10.dp)).padding(12.dp))
                    SliderRow("Text size", active.size, 18f..120f) { v -> textLayers = textLayers.map { if (it.id == active.id) it.copy(size = v) else it } }
                    SliderRow("Text scale", active.scale, 0.3f..3f) { v -> textLayers = textLayers.map { if (it.id == active.id) it.copy(scale = v) else it } }
                    SliderRow("Text rotation", active.rotation, -180f..180f) { v -> textLayers = textLayers.map { if (it.id == active.id) it.copy(rotation = v) else it } }
                    SliderRow("Text opacity", active.opacity, 0f..1f) { v -> textLayers = textLayers.map { if (it.id == active.id) it.copy(opacity = v) else it } }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(bold = !it.bold) else it } }) { Text("Bold") }
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(italic = !it.italic) else it } }) { Text("Italic") }
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(shadow = !it.shadow) else it } }) { Text("Shadow") }
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(outline = !it.outline) else it } }) { Text("Outline") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(x = 0.5f, y = 0.5f, scale = 1f, rotation = 0f) else it } }) { Text("Reset") }
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(alignment = "left") else it } }) { Text("Left") }
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(alignment = "center") else it } }) { Text("Center") }
                        OutlinedButton(onClick = { textLayers = textLayers.map { if (it.id == active.id) it.copy(alignment = "right") else it } }) { Text("Right") }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf("Minimal", "Modern", "Bold", "Elegant", "Digital", "Clock")) { presetName ->
                            AssistChip(onClick = {
                                val preset = when (presetName) {
                                    "Minimal" -> active.copy(id = System.nanoTime(), size = 38f, bold = false, shadow = false, outline = false, text = "MINIMAL")
                                    "Modern" -> active.copy(id = System.nanoTime(), size = 54f, bold = true, shadow = true, outline = false, text = "MODERN")
                                    "Bold" -> active.copy(id = System.nanoTime(), size = 78f, bold = true, shadow = true, outline = true, text = "BOLD")
                                    "Elegant" -> active.copy(id = System.nanoTime(), size = 48f, italic = true, shadow = true, outline = false, text = "Elegant")
                                    "Digital" -> active.copy(id = System.nanoTime(), size = 62f, bold = true, italic = false, shadow = false, outline = true, text = "12:45")
                                    else -> active.copy(id = System.nanoTime(), size = 88f, bold = false, shadow = true, outline = false, text = "12:45")
                                }
                                textLayers = textLayers + preset; activeTextId = preset.id
                            }, label = { Text(presetName) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(AndroidColor.WHITE, AndroidColor.YELLOW, AndroidColor.CYAN, AndroidColor.RED).forEach { color ->
                            Box(Modifier.size(30.dp).background(Color(color), RoundedCornerShape(50)).clickable { textLayers = textLayers.map { if (it.id == active.id) it.copy(color = color) else it } })
                        }
                        OutlinedButton(onClick = { val copy = active.copy(id = System.nanoTime()); textLayers = textLayers + copy; activeTextId = copy.id }) { Text("Duplicate") }
                    }
                }
                Text("EXPORT", color = DepthAccent, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("720p", "1080p", "1440p").forEach { value -> FilterChip(selected = resolution == value, onClick = { resolution = value }, label = { Text(value) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("PNG", "JPEG").forEach { value -> FilterChip(selected = format == value, onClick = { format = value }, label = { Text(value) }) }
                }
                GoldButton("Export wallpaper", onClick = {
                    val item = selected ?: return@GoldButton
                    scope.launch {
                        busy = true
                        runCatching {
                            withContext(Dispatchers.IO) {
                                val size = when (resolution) { "720p" -> 720; "1440p" -> 1440; else -> 1080 }
                                val h = (size * 16f / 9f).toInt().coerceAtMost(2560)
                                val bitmap = StudioRenderer.render(item.file, backgroundFile, size, h,
                                    StudioRenderOptions(backgroundColor, bgBrightness, blur, fgBrightness, scale, x, y, rotation, foregroundVisible, backgroundVisible), textLayers)
                                val folder = File(context.filesDir, "exports").apply { mkdirs() }
                                File(folder, if (format == "PNG") "latest_wallpaper.jpg" else "latest_wallpaper.png").delete()
                                val file = File(folder, "latest_wallpaper.${if (format == "PNG") "png" else "jpg"}")
                                try {
                                    val encoded = FileOutputStream(file).use { bitmap.compress(if (format == "PNG") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
                                    check(encoded) { "Image encoding failed." }
                                    if (Build.VERSION.SDK_INT >= 29) saveToMediaStore(context, bitmap, format)
                                    file
                                } finally {
                                    bitmap.recycle()
                                }
                            }
                        }.onSuccess { file ->
                            exportFile = file
                            if (Build.VERSION.SDK_INT >= 29) status = "Wallpaper exported to Pictures/DEPTHIFY."
                            else {
                                status = "Choose where to save your wallpaper."
                                val mime = if (format == "PNG") "image/png" else "image/jpeg"
                                val extension = if (format == "PNG") "png" else "jpg"
                                val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
                                    addCategory(android.content.Intent.CATEGORY_OPENABLE)
                                    type = mime
                                    putExtra(android.content.Intent.EXTRA_TITLE, "DEPTHIFY_${System.currentTimeMillis()}.$extension")
                                }
                                legacySaveLauncher.launch(intent)
                            }
                        }.onFailure { status = it.message ?: "Export failed." }
                        busy = false
                    }
                }, modifier = Modifier.fillMaxWidth(), enabled = !busy)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = exportFile != null, onClick = { pendingWallpaperTarget = WallpaperTarget.Home }) { Text("Set Home") }
                    OutlinedButton(enabled = exportFile != null, onClick = { pendingWallpaperTarget = WallpaperTarget.Lock }) { Text("Set Lock") }
                    OutlinedButton(enabled = exportFile != null, onClick = { pendingWallpaperTarget = WallpaperTarget.Both }) { Text("Both") }
                }
                OutlinedButton(enabled = exportFile != null, onClick = {
                    val intent = android.content.Intent(android.app.WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                        putExtra(android.app.WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, android.content.ComponentName(context, com.depthify.wallpaper.live.DepthifyLiveWallpaperService::class.java))
                    }
                    context.startActivity(intent)
                }, modifier = Modifier.fillMaxWidth()) { Text("Preview Live Wallpaper") }
                status?.let { Text(it, color = DepthTextSecondary, fontSize = 12.sp) }
            }
        }
    }
    val targetToApply = pendingWallpaperTarget
    if (targetToApply != null) {
        AlertDialog(
            onDismissRequest = { pendingWallpaperTarget = null },
            title = { Text("Apply wallpaper?") },
            text = { Text("DEPTHIFY will ask Android to set the exported image as ${targetToApply.name.lowercase()} wallpaper.") },
            confirmButton = { TextButton(onClick = {
                pendingWallpaperTarget = null
                val file = exportFile
                if (file != null) scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return@withContext Result.failure(IllegalStateException("Export image could not be opened."))
                        try { WallpaperApplier.apply(context, bitmap, targetToApply) } finally { bitmap.recycle() }
                    }
                    status = if (result.isSuccess) "Wallpaper applied." else result.exceptionOrNull()?.message ?: "Unable to apply wallpaper."
                }
            }) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { pendingWallpaperTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Column {
        Row { Text(label, color = DepthTextSecondary, modifier = Modifier.weight(1f)); Text("${(value * 100).toInt()}%", color = DepthTextSecondary) }
        Slider(value = value, onValueChange = onValue, valueRange = range)
    }
}

private fun saveToMediaStore(context: android.content.Context, bitmap: Bitmap, format: String) {
    val resolver = context.contentResolver
    val mime = if (format == "PNG") "image/png" else "image/jpeg"
    val name = "DEPTHIFY_${System.currentTimeMillis()}.${if (format == "PNG") "png" else "jpg"}"
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, mime)
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DEPTHIFY")
    }
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("Unable to create gallery item")
    try {
        resolver.openOutputStream(uri)?.use { bitmap.compress(if (format == "PNG") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
            ?: error("Unable to write exported image")
    } catch (error: Exception) {
        resolver.delete(uri, null, null)
        throw error
    }
}
