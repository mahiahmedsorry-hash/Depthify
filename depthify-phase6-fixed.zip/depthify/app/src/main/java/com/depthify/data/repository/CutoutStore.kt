package com.depthify.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import java.io.File
import java.util.Properties

/** Private, non-destructive cutout assets. Each folder is keyed by the imported original filename. */
class CutoutStore(context: Context) {
    private val root = File(context.filesDir, "cutouts").apply { mkdirs() }

    data class Entry(
        val key: String,
        val originalName: String,
        val maskFile: File,
        val foregroundFile: File,
        val metadataFile: File,
        val width: Int,
        val height: Int,
        val createdAt: Long
    )

    fun entry(key: String): Entry? {
        val safe = File(key).nameWithoutExtension
        val folder = File(root, safe)
        val meta = File(folder, "metadata.properties")
        if (!meta.exists()) return null
        return runCatching {
            val p = Properties().apply { meta.inputStream().use { load(it) } }
            Entry(
                key = safe,
                originalName = p.getProperty("originalName"),
                maskFile = File(folder, "mask.png"),
                foregroundFile = File(folder, "foreground.png"),
                metadataFile = meta,
                width = p.getProperty("width").toInt(),
                height = p.getProperty("height").toInt(),
                createdAt = p.getProperty("createdAt").toLong()
            ).takeIf { it.maskFile.exists() && it.foregroundFile.exists() }
        }.getOrNull()
    }

    fun list(): List<Entry> = root.listFiles()?.mapNotNull { entry(it.name) }
        ?.sortedByDescending { it.createdAt } ?: emptyList()

    fun loadMask(key: String): Bitmap? = entry(key)?.let { BitmapFactory.decodeFile(it.maskFile.absolutePath) }
    fun loadForeground(key: String): Bitmap? = entry(key)?.let { BitmapFactory.decodeFile(it.foregroundFile.absolutePath) }

    fun save(key: String, originalName: String, mask: Bitmap, foreground: Bitmap): Entry {
        val safe = File(key).nameWithoutExtension
        val folder = File(root, safe).apply { mkdirs() }
        val maskFile = File(folder, "mask.png")
        val foregroundFile = File(folder, "foreground.png")
        val alphaMask = Bitmap.createBitmap(mask.width, mask.height, Bitmap.Config.ALPHA_8)
        Canvas(alphaMask).drawBitmap(mask, null, Rect(0, 0, mask.width, mask.height), null)
        File(folder, "mask.tmp").outputStream().use { alphaMask.compress(Bitmap.CompressFormat.PNG, 100, it) }
        alphaMask.recycle()
        File(folder, "foreground.tmp").outputStream().use { foreground.compress(Bitmap.CompressFormat.PNG, 100, it) }
        File(folder, "mask.tmp").renameTo(maskFile)
        File(folder, "foreground.tmp").renameTo(foregroundFile)
        val now = System.currentTimeMillis()
        val metadata = File(folder, "metadata.properties")
        val properties = Properties().apply {
            setProperty("originalName", originalName)
            setProperty("width", foreground.width.toString())
            setProperty("height", foreground.height.toString())
            setProperty("createdAt", now.toString())
            setProperty("format", "DEPTHIFY_CUTOUT_V1")
        }
        metadata.outputStream().use { properties.store(it, "DEPTHIFY cutout metadata") }
        return entry(safe)!!
    }
}
