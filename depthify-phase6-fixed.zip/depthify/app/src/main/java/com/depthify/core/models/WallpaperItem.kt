package com.depthify.core.models

enum class ArtStyle { Skyline, NeonRoad, JetSky, Pitch, CyberGrid, Mountains, Galaxy, Waves, Minimal }

sealed interface WallpaperSource {
    /** Original artwork drawn in code. [palette] always holds 4 ARGB colors. */
    data class Procedural(val style: ArtStyle, val palette: List<Int>, val seed: Long) : WallpaperSource

    /** A photo the user imported; the untouched copy lives in app-private storage. */
    data class Imported(val fileName: String) : WallpaperSource
}

data class WallpaperItem(
    val id: String,
    val title: String,
    val category: WallpaperCategory,
    val source: WallpaperSource,
    val featured: Boolean = false,
    val trending: Boolean = false
) {
    val isImported: Boolean get() = source is WallpaperSource.Imported
}
