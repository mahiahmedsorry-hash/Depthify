package com.depthify.ui.studio

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.depthify.ui.components.GlassCard
import com.depthify.ui.components.GoldButton
import com.depthify.ui.components.PlaceholderCard
import com.depthify.ui.components.ScreenContainer
import com.depthify.ui.theme.DepthTextSecondary

@Composable
fun CreateScreen(onQuickMode: () -> Unit, onOpenStudio: () -> Unit) {
    ScreenContainer(title = "Create", subtitle = "Choose how you want to build your wallpaper") {
        GlassCard(Modifier) {
            Text("Quick Mode", style = MaterialTheme.typography.titleLarge)
            Text("Choose a photo and create a transparent subject cutout. People are detected automatically; other subjects can be masked by hand.", color = DepthTextSecondary)
            GoldButton("Start Cutout", onQuickMode)
        }
        GlassCard(Modifier) {
            Text("Depth Studio", style = MaterialTheme.typography.titleLarge)
            Text("Compose saved cutouts with backgrounds, text layers, effects and wallpaper export.", color = DepthTextSecondary)
            GoldButton("Open Studio", onOpenStudio)
        }
    }
}
