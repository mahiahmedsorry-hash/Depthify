package com.depthify.engine.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import com.depthify.core.models.ArtStyle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/**
 * Draws the built-in wallpapers. Everything is generated from code, so no image
 * files are bundled and no third-party artwork is involved. The same seed always
 * produces the same picture, at any resolution.
 */
object ProceduralRenderer {

    fun render(style: ArtStyle, palette: List<Int>, seed: Long, width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val w = width.toFloat()
        val h = height.toFloat()
        val rnd = Random(seed)
        when (style) {
            ArtStyle.Skyline -> skyline(canvas, w, h, palette, rnd)
            ArtStyle.NeonRoad -> neonRoad(canvas, w, h, palette, rnd)
            ArtStyle.JetSky -> jetSky(canvas, w, h, palette, rnd)
            ArtStyle.Pitch -> pitch(canvas, w, h, palette)
            ArtStyle.CyberGrid -> cyberGrid(canvas, w, h, palette, rnd)
            ArtStyle.Mountains -> mountains(canvas, w, h, palette, rnd)
            ArtStyle.Galaxy -> galaxy(canvas, w, h, palette, rnd)
            ArtStyle.Waves -> waves(canvas, w, h, palette, rnd)
            ArtStyle.Minimal -> minimal(canvas, w, h, palette, rnd)
        }
        return bitmap
    }

    // ---------- shared helpers ----------

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private fun blend(a: Int, b: Int, t: Float): Int = ColorUtils.blendARGB(a, b, t.coerceIn(0f, 1f))

    private fun solid(color: Int, alpha: Int = 255): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.alpha = alpha
        }

    private fun stroke(color: Int, width: Float, alpha: Int = 255): Paint =
        solid(color, alpha).apply {
            style = Paint.Style.STROKE
            strokeWidth = width
        }

    private fun fillVertical(c: Canvas, w: Float, y0: Float, y1: Float, top: Int, bottom: Int) {
        val paint = Paint()
        paint.shader = LinearGradient(0f, y0, 0f, y1, top, bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, y0, w, y1, paint)
    }

    private fun glow(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int, alpha: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = RadialGradient(
            cx, cy, radius, withAlpha(color, alpha), withAlpha(color, 0), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, radius, paint)
    }

    // ---------- Anime: moonlit city skyline ----------
    // palette: sky top, sky bottom, moon/petals, silhouette

    private fun skyline(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        val k = w / 540f
        fillVertical(c, w, 0f, h, pal[0], pal[1])

        val star = solid(Color.WHITE)
        repeat(60) {
            star.alpha = 60 + rnd.nextInt(150)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.5f, (0.6f + rnd.nextFloat() * 1.6f) * k, star)
        }

        val mx = w * (0.55f + rnd.nextFloat() * 0.3f)
        val my = h * 0.2f
        val mr = w * 0.14f
        glow(c, mx, my, mr * 3.2f, pal[2], 110)
        c.drawCircle(mx, my, mr, solid(pal[2]))

        drawCity(c, w, h * 0.80f, h * 0.20f, blend(pal[3], pal[1], 0.35f), rnd, false, pal[2])
        drawCity(c, w, h * 0.86f, h * 0.28f, pal[3], rnd, true, pal[2])
        c.drawRect(0f, h * 0.93f, w, h, solid(pal[3]))

        val petal = solid(pal[2])
        repeat(28) {
            petal.alpha = 80 + rnd.nextInt(120)
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h * 0.9f
            val s = (4f + rnd.nextFloat() * 6f) * k
            c.save()
            c.rotate(rnd.nextFloat() * 180f, x, y)
            c.drawOval(RectF(x - s, y - s * 0.55f, x + s, y + s * 0.55f), petal)
            c.restore()
        }
    }

    private fun drawCity(
        c: Canvas, w: Float, baseY: Float, maxH: Float, color: Int,
        rnd: Random, lights: Boolean, lightColor: Int
    ) {
        val paint = solid(color)
        val window = solid(lightColor, 200)
        var x = -w * 0.02f
        while (x < w) {
            val bw = w * (0.05f + rnd.nextFloat() * 0.08f)
            val bh = maxH * (0.35f + rnd.nextFloat() * 0.65f)
            c.drawRect(x, baseY - bh, x + bw, baseY + maxH, paint)
            if (lights) {
                val ws = bw / 6f
                var wy = baseY - bh + ws * 2f
                while (wy < baseY - ws * 2f) {
                    var wx = x + ws
                    while (wx < x + bw - ws * 1.5f) {
                        if (rnd.nextFloat() < 0.18f) c.drawRect(wx, wy, wx + ws, wy + ws * 1.4f, window)
                        wx += ws * 2f
                    }
                    wy += ws * 2.6f
                }
            }
            x += bw
        }
    }

    // ---------- Cars: neon retro drive ----------
    // palette: sky top, horizon, neon, road

    private fun neonRoad(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        val k = w / 540f
        val hy = h * 0.55f
        fillVertical(c, w, 0f, hy, pal[0], pal[1])

        val star = solid(Color.WHITE)
        repeat(50) {
            star.alpha = 50 + rnd.nextInt(150)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * hy * 0.8f, (0.6f + rnd.nextFloat() * 1.2f) * k, star)
        }

        val r = w * 0.3f
        val sunY = hy - r * 0.35f
        glow(c, w / 2f, sunY, r * 2.2f, pal[2], 90)
        c.save()
        c.clipRect(0f, 0f, w, hy)
        val sun = Paint(Paint.ANTI_ALIAS_FLAG)
        sun.shader = LinearGradient(0f, sunY - r, 0f, hy, pal[2], pal[1], Shader.TileMode.CLAMP)
        c.drawCircle(w / 2f, sunY, r, sun)
        for (i in 0 until 6) {
            val y = sunY + r * i * 0.07f
            val thickness = r * (0.012f + i * 0.012f)
            val skyColor = blend(pal[0], pal[1], y / hy)
            c.drawRect(w / 2f - r, y, w / 2f + r, y + thickness, solid(skyColor))
        }
        c.restore()

        c.drawRect(0f, hy, w, h, solid(pal[3]))
        c.drawRect(0f, hy - 2f * k, w, hy + 2f * k, solid(pal[2]))

        val line = stroke(pal[2], 2f * k, 170)
        for (i in -6..14) {
            c.drawLine(w / 2f, hy, w * i / 8f, h, line)
        }
        for (i in 1..12) {
            val t = i / 12f
            val y = hy + (h - hy) * t * t
            c.drawLine(0f, y, w, y, line)
        }

        // generic side-view car silhouette
        val carW = w * 0.46f
        val carH = carW * 0.3f
        val left = w / 2f - carW / 2f
        val base = h * 0.84f
        glow(c, w / 2f, base, carW * 0.8f, pal[2], 70)
        val bodyRect = RectF(left, base - carH * 0.55f, left + carW, base)
        val cabin = Path()
        cabin.moveTo(left + carW * 0.2f, base - carH * 0.55f)
        cabin.lineTo(left + carW * 0.32f, base - carH)
        cabin.lineTo(left + carW * 0.68f, base - carH)
        cabin.lineTo(left + carW * 0.82f, base - carH * 0.55f)
        cabin.close()
        val black = solid(Color.BLACK)
        c.drawRoundRect(bodyRect, carH * 0.2f, carH * 0.2f, black)
        c.drawPath(cabin, black)
        val neon = stroke(pal[2], 2.5f * k)
        c.drawRoundRect(bodyRect, carH * 0.2f, carH * 0.2f, neon)
        c.drawPath(cabin, neon)
        val wheelR = carH * 0.3f
        for (wx in listOf(left + carW * 0.22f, left + carW * 0.78f)) {
            c.drawCircle(wx, base, wheelR, solid(0xFF111111.toInt()))
            c.drawCircle(wx, base, wheelR * 0.55f, stroke(pal[2], 2f * k))
        }
        c.drawRect(left + carW * 0.1f, base + 2f * k, left + carW * 0.9f, base + 6f * k, solid(pal[2], 200))
    }

    // ---------- Aircraft: jet above the clouds ----------
    // palette: sky top, sky bottom, contrail/clouds, jet

    private fun jetSky(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        fillVertical(c, w, 0f, h, pal[0], pal[1])
        repeat(7) {
            glow(
                c, rnd.nextFloat() * w, h * (0.1f + rnd.nextFloat() * 0.8f),
                w * (0.25f + rnd.nextFloat() * 0.35f), pal[2], 70
            )
        }

        c.save()
        c.translate(w * 0.5f, h * 0.42f)
        c.rotate(-24f)
        val s = w * 0.42f
        c.scale(s, s)

        val trail = Paint()
        trail.shader = LinearGradient(
            0f, 0.9f, 0f, 4.5f, withAlpha(pal[2], 200), withAlpha(pal[2], 0), Shader.TileMode.CLAMP
        )
        c.drawRect(-0.22f, 0.9f, -0.14f, 4.5f, trail)
        c.drawRect(0.14f, 0.9f, 0.22f, 4.5f, trail)

        val right = floatArrayOf(
            0.12f, -0.45f, 0.14f, 0.0f, 0.95f, 0.6f, 0.95f, 0.78f, 0.16f, 0.55f,
            0.12f, 0.85f, 0.34f, 1.05f, 0.34f, 1.15f, 0.0f, 1.05f
        )
        val path = Path()
        path.moveTo(0f, -1f)
        var i = 0
        while (i < right.size) {
            path.lineTo(right[i], right[i + 1])
            i += 2
        }
        i = right.size - 2
        while (i >= 0) {
            path.lineTo(-right[i], right[i + 1])
            i -= 2
        }
        path.close()
        c.drawPath(path, solid(pal[3]))
        c.drawPath(path, stroke(pal[2], 0.012f, 130))
        c.drawOval(RectF(-0.07f, -0.55f, 0.07f, -0.15f), solid(pal[2], 230))
        glow(c, 0f, 1.12f, 0.22f, pal[2], 220)
        c.restore()
    }

    // ---------- Football: floodlit pitch ----------
    // palette: dark grass, light grass, lines, floodlight

    private fun pitch(c: Canvas, w: Float, h: Float, pal: List<Int>) {
        val bands = 12
        for (i in 0 until bands) {
            c.drawRect(0f, h * i / bands, w, h * (i + 1) / bands, solid(if (i % 2 == 0) pal[0] else pal[1]))
        }
        val m = w * 0.08f
        val top = h * 0.06f
        val bottom = h * 0.94f
        val line = stroke(pal[2], w * 0.006f, 230)
        c.drawRect(m, top, w - m, bottom, line)
        c.drawLine(m, h / 2f, w - m, h / 2f, line)
        c.drawCircle(w / 2f, h / 2f, w * 0.18f, line)
        c.drawCircle(w / 2f, h / 2f, w * 0.012f, solid(pal[2]))
        val bw = w * 0.5f
        val bh = h * 0.12f
        c.drawRect((w - bw) / 2f, top, (w + bw) / 2f, top + bh, line)
        c.drawRect((w - bw) / 2f, bottom - bh, (w + bw) / 2f, bottom, line)
        val sw = w * 0.24f
        val sh = h * 0.05f
        c.drawRect((w - sw) / 2f, top, (w + sw) / 2f, top + sh, line)
        c.drawRect((w - sw) / 2f, bottom - sh, (w + sw) / 2f, bottom, line)

        glow(c, 0f, 0f, w * 1.1f, pal[3], 120)
        glow(c, w, 0f, w * 1.1f, pal[3], 120)
        val vignette = Paint()
        vignette.shader = RadialGradient(
            w / 2f, h / 2f, h * 0.75f,
            intArrayOf(Color.TRANSPARENT, Color.argb(176, 0, 0, 0)),
            floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, vignette)
    }

    // ---------- Gaming: neon tile grid and controller ----------
    // palette: bg top, bg bottom, neon 1, neon 2

    private fun cyberGrid(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        val k = w / 540f
        fillVertical(c, w, 0f, h, pal[0], pal[1])
        val cols = 10
        val cell = w / cols
        val rows = (h / cell).toInt() + 1
        val tile = Paint(Paint.ANTI_ALIAS_FLAG)
        for (r in 0 until rows) {
            for (col in 0 until cols) {
                val roll = rnd.nextFloat()
                if (roll < 0.14f) {
                    tile.color = if (roll < 0.07f) pal[2] else pal[3]
                    tile.alpha = 25 + rnd.nextInt(60)
                    val g = cell * 0.08f
                    c.drawRect(col * cell + g, r * cell + g, (col + 1) * cell - g, (r + 1) * cell - g, tile)
                }
            }
        }
        val gridLine = stroke(pal[2], max(1f, k), 28)
        for (i in 0..cols) c.drawLine(i * cell, 0f, i * cell, h, gridLine)
        for (r in 0..rows) c.drawLine(0f, r * cell, w, r * cell, gridLine)
        glow(c, w * 0.15f, h * 0.25f, w * 0.7f, pal[2], 90)
        glow(c, w * 0.9f, h * 0.7f, w * 0.8f, pal[3], 80)

        // generic game controller silhouette
        val cx = w / 2f
        val cy = h * 0.62f
        val cw = w * 0.74f
        val ch = cw * 0.4f
        glow(c, cx, cy, cw * 0.8f, pal[2], 80)
        val rect = RectF(cx - cw / 2f, cy - ch / 2f, cx + cw / 2f, cy + ch / 2f)
        c.drawRoundRect(rect, ch * 0.5f, ch * 0.5f, solid(blend(pal[0], Color.BLACK, 0.4f)))
        c.drawRoundRect(rect, ch * 0.5f, ch * 0.5f, stroke(pal[2], 3f * k))
        val dx = cx - cw * 0.26f
        val a = ch * 0.1f
        val dpad = solid(pal[2])
        c.drawRoundRect(RectF(dx - a * 2f, cy - a * 0.7f, dx + a * 2f, cy + a * 0.7f), a * 0.3f, a * 0.3f, dpad)
        c.drawRoundRect(RectF(dx - a * 0.7f, cy - a * 2f, dx + a * 0.7f, cy + a * 2f), a * 0.3f, a * 0.3f, dpad)
        val bx = cx + cw * 0.24f
        val br = ch * 0.085f
        c.drawCircle(bx + br * 2.3f, cy, br, solid(pal[3]))
        c.drawCircle(bx - br * 2.3f, cy, br, solid(pal[2]))
        c.drawCircle(bx, cy - br * 2.3f, br, solid(pal[3]))
        c.drawCircle(bx, cy + br * 2.3f, br, solid(pal[2]))
        c.drawCircle(cx - cw * 0.08f, cy + ch * 0.18f, br * 1.4f, stroke(pal[2], 2f * k))
        c.drawCircle(cx + cw * 0.08f, cy + ch * 0.18f, br * 1.4f, stroke(pal[3], 2f * k))
    }

    // ---------- Nature: layered mountains and pines ----------
    // palette: sky top, sky bottom, sun, mountain

    private fun mountains(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        fillVertical(c, w, 0f, h * 0.75f, pal[0], pal[1])
        c.drawRect(0f, h * 0.75f, w, h, solid(pal[1]))
        val sx = w * (0.3f + rnd.nextFloat() * 0.4f)
        val sy = h * 0.3f
        glow(c, sx, sy, w * 0.8f, pal[2], 120)
        c.drawCircle(sx, sy, w * 0.09f, solid(pal[2]))

        val layers = 4
        for (i in 0 until layers) {
            val t = i / (layers - 1f)
            val color = blend(pal[1], pal[3], 0.35f + 0.65f * t)
            val baseY = h * (0.42f + 0.13f * i)
            val amp = h * (0.14f - 0.015f * i)
            val phase = rnd.nextFloat() * 6.28f
            val path = Path()
            path.moveTo(0f, h)
            val steps = 14
            for (s in 0..steps) {
                val x = w * s / steps
                val y = baseY - amp * (0.55f * abs(sin(phase + s * 0.9f + i)) + 0.45f * rnd.nextFloat())
                path.lineTo(x, y)
            }
            path.lineTo(w, h)
            path.close()
            c.drawPath(path, solid(color))

            val mist = Paint()
            mist.shader = LinearGradient(
                0f, baseY - amp * 0.3f, 0f, baseY + amp * 0.5f,
                withAlpha(pal[1], 0), withAlpha(pal[1], 110), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, baseY - amp * 0.3f, w, baseY + amp * 0.5f, mist)
        }

        val tree = solid(blend(pal[3], Color.BLACK, 0.45f))
        repeat(14) {
            val x = rnd.nextFloat() * w
            val s = w * (0.04f + rnd.nextFloat() * 0.05f)
            val base = h * (0.97f + rnd.nextFloat() * 0.05f)
            for (j in 0 until 3) {
                val bottomY = base - j * s * 0.9f
                val topY = bottomY - s * 1.5f
                val half = s * (1.5f - j * 0.3f) / 2f
                val p = Path()
                p.moveTo(x, topY)
                p.lineTo(x - half, bottomY)
                p.lineTo(x + half, bottomY)
                p.close()
                c.drawPath(p, tree)
            }
        }
    }

    // ---------- Space: nebula, stars and a ringed planet ----------
    // palette: background, nebula A, nebula B, planet

    private fun galaxy(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        val k = w / 540f
        fillVertical(c, w, 0f, h, pal[0], blend(pal[0], Color.BLACK, 0.5f))
        glow(c, w * 0.2f, h * 0.2f, w * 0.9f, pal[1], 120)
        glow(c, w * 0.85f, h * 0.45f, w * 1.0f, pal[2], 90)
        glow(c, w * 0.4f, h * 0.9f, w * 0.9f, pal[1], 70)

        val star = solid(Color.WHITE)
        repeat(180) {
            star.alpha = 40 + rnd.nextInt(200)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h, (0.5f + rnd.nextFloat() * 1.4f) * k, star)
        }
        repeat(8) {
            glow(c, rnd.nextFloat() * w, rnd.nextFloat() * h * 0.6f, 14f * k, Color.WHITE, 200)
        }

        val r = w * 0.30f
        val cx = w * 0.32f
        val cy = h * 0.7f
        val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = r * 0.09f
        ring.color = withAlpha(pal[3], 170)
        val oval = RectF(cx - r * 1.75f, cy - r * 0.38f, cx + r * 1.75f, cy + r * 0.38f)

        c.save()
        c.rotate(-18f, cx, cy)
        c.drawArc(oval, 180f, 180f, false, ring)
        c.restore()

        val planet = Paint(Paint.ANTI_ALIAS_FLAG)
        planet.shader = RadialGradient(
            cx - r * 0.4f, cy - r * 0.4f, r * 1.5f,
            pal[3], blend(pal[3], Color.BLACK, 0.75f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, planet)

        c.save()
        c.rotate(-18f, cx, cy)
        c.drawArc(oval, 0f, 180f, false, ring)
        c.restore()
    }

    // ---------- Abstract: flowing wave bands ----------
    // palette: bg top, bg bottom, color 1, color 2

    private fun waves(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        fillVertical(c, w, 0f, h, pal[0], pal[1])
        glow(c, w * 0.8f, h * 0.2f, w * 0.9f, pal[2], 90)
        glow(c, w * 0.1f, h * 0.75f, w * 0.9f, pal[3], 80)
        val bands = 7
        for (i in 0 until bands) {
            val t = i / (bands - 1f)
            val color = blend(pal[2], pal[3], t)
            val baseY = h * (0.28f + 0.1f * i)
            val amp = h * (0.025f + 0.012f * i)
            val freq = (1.2f + rnd.nextFloat() * 1.4f) * 6.2832f / w
            val phase = rnd.nextFloat() * 6.28f
            val path = Path()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w) {
                path.lineTo(x, baseY + amp * sin(freq * x + phase))
                x += w / 48f
            }
            path.lineTo(w, h)
            path.close()
            c.drawPath(path, solid(color, 150))
        }
    }

    // ---------- Minimal: calm shapes ----------
    // palette: bg top, bg bottom, shape 1, shape 2

    private fun minimal(c: Canvas, w: Float, h: Float, pal: List<Int>, rnd: Random) {
        fillVertical(c, w, 0f, h, pal[0], pal[1])
        val big = w * (0.55f + rnd.nextFloat() * 0.2f)
        val cx = w * (0.25f + rnd.nextFloat() * 0.5f)
        val cy = h * (0.3f + rnd.nextFloat() * 0.2f)
        c.drawCircle(cx, cy, big, solid(pal[3], 140))
        c.drawCircle(cx + big * 0.25f, cy + big * 0.1f, big * 0.55f, solid(pal[2]))
        c.drawLine(w * 0.12f, h * 0.86f, w * 0.88f, h * 0.86f, stroke(pal[2], w * 0.004f, 200))
        c.drawCircle(w * 0.84f, h * 0.9f, w * 0.014f, solid(pal[2]))
        c.drawCircle(w * 0.78f, h * 0.9f, w * 0.014f, solid(pal[3]))
    }
}
