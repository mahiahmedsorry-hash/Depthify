package com.depthify.engine.rendering

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import com.depthify.core.image.BitmapDecoder
import com.depthify.core.models.WallpaperItem
import com.depthify.core.models.WallpaperSource
import com.depthify.data.repository.ImportedPhotoStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Renders or decodes wallpapers at three sizes: grid thumbnails, fullscreen preview and
 * full device resolution (for Apply / Save). Thumbnails and previews are kept in a
 * size-limited in-memory cache; full-resolution bitmaps are never cached.
 */
class WallpaperLoader(context: Context, private val store: ImportedPhotoStore) {

    private val metrics = context.resources.displayMetrics

    /** Device screen in portrait orientation. */
    val screenWidth: Int = min(metrics.widthPixels, metrics.heightPixels)
    val screenHeight: Int = max(metrics.widthPixels, metrics.heightPixels)

    val thumbWidth: Int = 270
    val thumbHeight: Int = 480

    val previewWidth: Int = 720
    val previewHeight: Int = (720f * screenHeight / screenWidth).roundToInt()

    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).coerceAtMost(48L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun key(item: WallpaperItem, width: Int, height: Int) = "${item.id}@${width}x$height"

    fun cached(item: WallpaperItem, width: Int, height: Int): Bitmap? = cache.get(key(item, width, height))

    /** Returns null when the wallpaper cannot be produced (corrupt file, out of memory). */
    suspend fun load(item: WallpaperItem, width: Int, height: Int, useCache: Boolean = true): Bitmap? =
        withContext(Dispatchers.Default) {
            val cacheKey = key(item, width, height)
            if (useCache) {
                cache.get(cacheKey)?.let { return@withContext it }
            }
            val bitmap: Bitmap? = try {
                when (val source = item.source) {
                    is WallpaperSource.Procedural ->
                        ProceduralRenderer.render(source.style, source.palette, source.seed, width, height)
                    is WallpaperSource.Imported ->
                        BitmapDecoder.decodeCropped(store.file(source.fileName), width, height)
                }
            } catch (e: OutOfMemoryError) {
                null
            } catch (e: Exception) {
                null
            }
            if (bitmap != null && useCache) cache.put(cacheKey, bitmap)
            bitmap
        }

    /** Blocking (reads file headers for photos). Call from a background dispatcher. */
    fun resolutionLabel(item: WallpaperItem): String =
        when (val source = item.source) {
            is WallpaperSource.Procedural ->
                "$screenWidth × $screenHeight px · drawn at your screen resolution"
            is WallpaperSource.Imported -> {
                val size = BitmapDecoder.readSize(store.file(source.fileName))
                if (size == null) "Size unknown" else "Original photo ${size.width} × ${size.height} px"
            }
        }
}
