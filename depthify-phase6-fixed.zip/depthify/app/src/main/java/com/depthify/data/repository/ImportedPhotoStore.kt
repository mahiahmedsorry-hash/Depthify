package com.depthify.data.repository

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import com.depthify.core.image.BitmapDecoder
import com.depthify.core.models.WallpaperCategory
import com.depthify.core.models.WallpaperItem
import com.depthify.core.models.WallpaperSource
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Keeps an untouched copy of every imported photo in app-private storage
 * (filesDir/originals). Nothing here is visible to other apps and nothing is uploaded.
 */
class ImportedPhotoStore(context: Context) {

    private val dir = File(context.filesDir, "originals").apply { mkdirs() }

    /** Resolves a stored file by name; any path segments in [name] are dropped. */
    fun file(name: String): File = File(dir, File(name).name)

    fun list(): List<WallpaperItem> =
        dir.listFiles()
            ?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.map { itemFor(it) }
            ?: emptyList()

    fun delete(fileName: String): Boolean = file(fileName).delete()

    /** Blocking. Call from a background dispatcher. Throws when the file is not a readable image. */
    fun importFrom(resolver: ContentResolver, uri: Uri): WallpaperItem {
        val extension = when (resolver.getType(uri)) {
            "image/jpeg" -> "jpg"
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/heic" -> "heic"
            "image/heif" -> "heif"
            "image/gif" -> "gif"
            else -> "img"
        }
        val target = File(dir, "photo-${System.currentTimeMillis()}.$extension")
        try {
            val input = resolver.openInputStream(uri) ?: error("Could not open the selected photo.")
            input.use { source -> target.outputStream().use { sink -> source.copyTo(sink) } }
            if (BitmapDecoder.readSize(target) == null) {
                error("This file is not a supported image.")
            }
            val digest = sha256(target)
            val duplicate = dir.listFiles()?.firstOrNull {
                it.isFile && it.name != target.name && runCatching { sha256(it) == digest }.getOrDefault(false)
            }
            if (duplicate != null) {
                target.delete()
                return itemFor(duplicate)
            }
        } catch (e: Throwable) {
            target.delete()
            throw e
        }
        return itemFor(target)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun itemFor(file: File): WallpaperItem {
        val stamp = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(file.lastModified()))
        return WallpaperItem(
            id = "imported:${file.name}",
            title = "Photo $stamp",
            category = WallpaperCategory.Custom,
            source = WallpaperSource.Imported(file.name)
        )
    }
}
