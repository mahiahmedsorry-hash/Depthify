package com.depthify.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

const val PREVIEW_ROUTE = "preview"

enum class MainTab(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    Home("home", "Home", Icons.Outlined.Home, Icons.Filled.Home),
    Explore("explore", "Explore", Icons.Outlined.Explore, Icons.Filled.Explore),
    Create("create", "Create", Icons.Outlined.AddCircleOutline, Icons.Filled.AddCircle),
    Library("library", "Library", Icons.Outlined.PhotoLibrary, Icons.Filled.PhotoLibrary),
    Settings("settings", "Settings", Icons.Outlined.Settings, Icons.Filled.Settings)
}
