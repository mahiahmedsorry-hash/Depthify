package com.depthify.segmentation

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.nio.ByteOrder
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Single-image, fully bundled ML Kit person segmentation. */
class MlKitPersonSegmenter : SubjectSegmenter {
    override suspend fun segment(image: Bitmap): Bitmap {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        val segmenter = Segmentation.getClient(options)
        try {
            val result = suspendCancellableCoroutine { continuation ->
                segmenter.process(InputImage.fromBitmap(image, 0))
                    .addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
                    .addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
            }
            val buffer = result.buffer.apply { rewind(); order(ByteOrder.nativeOrder()) }
            val mask = Bitmap.createBitmap(result.width, result.height, Bitmap.Config.ARGB_8888)
            val pixels = IntArray(result.width * result.height)
            for (i in pixels.indices) {
                val confidence = buffer.float.coerceIn(0f, 1f)
                val t = ((confidence - 0.22f) / 0.56f).coerceIn(0f, 1f)
                val smooth = t * t * (3f - 2f * t)
                val alpha = (smooth * 255f).toInt()
                pixels[i] = Color.argb(alpha, 255, 255, 255)
            }
            mask.setPixels(pixels, 0, result.width, 0, 0, result.width, result.height)
            val scaled = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
            Canvas(scaled).drawBitmap(mask, null, android.graphics.Rect(0, 0, image.width, image.height), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            mask.recycle()
            return scaled
        } finally {
            segmenter.close()
        }
    }
}
