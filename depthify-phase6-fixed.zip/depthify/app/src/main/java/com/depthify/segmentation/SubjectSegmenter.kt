package com.depthify.segmentation

import android.graphics.Bitmap

/** Plug-in boundary for future MediaPipe/LiteRT models. Implementations return a white-on-black alpha mask. */
interface SubjectSegmenter {
    suspend fun segment(image: Bitmap): Bitmap
}
