package com.depthify.core.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Memory-safe decoding for imported photos. Never loads more pixels than needed. */
object BitmapDecoder {

    data class ImageSize(val width: Int, val height: Int)

    /** Real pixel size of the photo as the user sees it (EXIF rotation applied). */
    fun readSize(file: File): ImageSize? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        return if (swapsAxes(readOrientation(file))) {
            ImageSize(bounds.outHeight, bounds.outWidth)
        } else {
            ImageSize(bounds.outWidth, bounds.outHeight)
        }
    }

    /**
     * Decodes [file] downsampled, applies EXIF rotation, then center-crops to exactly
     * [targetW] x [targetH]. Returns null when the file is unreadable or memory runs out.
     */
    fun decodeCropped(file: File, targetW: Int, targetH: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val orientation = readOrientation(file)
        val swap = swapsAxes(orientation)
        val effW = if (swap) bounds.outHeight else bounds.outWidth
        val effH = if (swap) bounds.outWidth else bounds.outHeight

        var sample = 1
        val ratio = min(effW / targetW.toFloat(), effH / targetH.toFloat())
        while (sample * 2 <= ratio) sample *= 2

        var decoded: Bitmap? = null
        var attempt = 0
        while (decoded == null && attempt < 4) {
            try {
                decoded = BitmapFactory.decodeFile(
                    file.absolutePath,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                )
                if (decoded == null) return null
            } catch (e: OutOfMemoryError) {
                sample *= 2
                attempt++
            }
        }
        val source = decoded ?: return null

        val matrix = orientationMatrix(orientation)
        val oriented = if (matrix == null) {
            source
        } else {
            val rotated = try {
                Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
            } catch (e: OutOfMemoryError) {
                source.recycle()
                return null
            }
            if (rotated !== source) source.recycle()
            rotated
        }

        val result = try {
            coverCrop(oriented, targetW, targetH)
        } catch (e: OutOfMemoryError) {
            null
        }
        oriented.recycle()
        return result
    }

    private fun coverCrop(src: Bitmap, targetW: Int, targetH: Int): Bitmap {
        val out = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val scale = max(targetW / src.width.toFloat(), targetH / src.height.toFloat())
        val cropW = targetW / scale
        val cropH = targetH / scale
        val left = ((src.width - cropW) / 2f).roundToInt().coerceIn(0, src.width - 1)
        val top = ((src.height - cropH) / 2f).roundToInt().coerceIn(0, src.height - 1)
        val right = (left + cropW).roundToInt().coerceIn(left + 1, src.width)
        val bottom = (top + cropH).roundToInt().coerceIn(top + 1, src.height)
        Canvas(out).drawBitmap(src, Rect(left, top, right, bottom), Rect(0, 0, targetW, targetH), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun readOrientation(file: File): Int = try {
        ExifInterface(file.absolutePath)
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } catch (e: Exception) {
        ExifInterface.ORIENTATION_NORMAL
    }

    private fun swapsAxes(o: Int): Boolean =
        o == ExifInterface.ORIENTATION_ROTATE_90 ||
            o == ExifInterface.ORIENTATION_ROTATE_270 ||
            o == ExifInterface.ORIENTATION_TRANSPOSE ||
            o == ExifInterface.ORIENTATION_TRANSVERSE

    private fun orientationMatrix(o: Int): Matrix? {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                m.postRotate(90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                m.postRotate(270f)
                m.postScale(-1f, 1f)
            }
            else -> return null
        }
        return m
    }
}
