package com.depthify.data.repository

import com.depthify.core.models.ArtStyle
import com.depthify.core.models.WallpaperCategory
import com.depthify.core.models.WallpaperItem
import com.depthify.core.models.WallpaperSource

/**
 * The built-in collection: 9 categories x 4 original wallpapers, all generated in code.
 * Palette order per style is documented in ProceduralRenderer.
 */
object WallpaperCatalog {

    private class Variant(val title: String, val palette: List<Int>)

    private class Definition(
        val category: WallpaperCategory,
        val style: ArtStyle,
        val variants: List<Variant>
    )

    private fun v(title: String, a: Long, b: Long, c: Long, d: Long) =
        Variant(title, listOf(a.toInt(), b.toInt(), c.toInt(), d.toInt()))

    private val definitions = listOf(
        Definition(
            WallpaperCategory.Anime, ArtStyle.Skyline, listOf(
                v("Sakura Dusk", 0xFF2B1B4D, 0xFFFF7BA9, 0xFFFFE3F0, 0xFF140B26),
                v("Midnight Moon", 0xFF050B24, 0xFF1D3B8B, 0xFFFFF3B0, 0xFF060A1A),
                v("Sunset Rooftops", 0xFF3A1C71, 0xFFFFAF7B, 0xFFFFE17D, 0xFF1A0F2E),
                v("Teal Twilight", 0xFF0B1F3A, 0xFF2EC4B6, 0xFFFDFFFC, 0xFF081426)
            )
        ),
        Definition(
            WallpaperCategory.Cars, ArtStyle.NeonRoad, listOf(
                v("Neon Drive", 0xFF12002B, 0xFFFF2E93, 0xFF00E5FF, 0xFF0A0A14),
                v("Gold Highway", 0xFF0A0A0A, 0xFF5C4300, 0xFFFFD600, 0xFF090909),
                v("Crimson Run", 0xFF1A0006, 0xFFB5173A, 0xFFFF6B6B, 0xFF0D0508),
                v("Ice Circuit", 0xFF04121F, 0xFF1E6091, 0xFF9DF0FF, 0xFF050B12)
            )
        ),
        Definition(
            WallpaperCategory.Aircraft, ArtStyle.JetSky, listOf(
                v("High Altitude", 0xFF0B3D91, 0xFF8EC5FC, 0xFFFFFFFF, 0xFF1C2230),
                v("Golden Hour Flight", 0xFF1B1B3A, 0xFFFFA45B, 0xFFFFF1D6, 0xFF14141F),
                v("Storm Chaser", 0xFF121826, 0xFF4B5D7A, 0xFFDCE6F5, 0xFF0B0F18),
                v("Dawn Patrol", 0xFF2D1E5F, 0xFFFF8FA3, 0xFFFFE8EC, 0xFF1A1226)
            )
        ),
        Definition(
            WallpaperCategory.Football, ArtStyle.Pitch, listOf(
                v("Matchday", 0xFF0B6B2E, 0xFF12873A, 0xFFFFFFFF, 0xFFFFF6B0),
                v("Night Stadium", 0xFF053D1C, 0xFF0A5A2A, 0xFFE6F4EA, 0xFF9DD6FF),
                v("Golden Turf", 0xFF1D5E1D, 0xFF2D7A2D, 0xFFFFF2B3, 0xFFFFD600),
                v("Blackout Pitch", 0xFF0D2B16, 0xFF123A1E, 0xFFFFD600, 0xFFFFFFFF)
            )
        ),
        Definition(
            WallpaperCategory.Gaming, ArtStyle.CyberGrid, listOf(
                v("Player One", 0xFF0A0014, 0xFF1B0A3A, 0xFF00F5D4, 0xFFFF2E93),
                v("Gold Rush", 0xFF050505, 0xFF1A1400, 0xFFFFD600, 0xFFFFFFFF),
                v("Toxic Level", 0xFF020B05, 0xFF08210F, 0xFF7CFF4F, 0xFF00C2FF),
                v("Red Zone", 0xFF0E0004, 0xFF2A0610, 0xFFFF3B3B, 0xFFFFB703)
            )
        ),
        Definition(
            WallpaperCategory.Nature, ArtStyle.Mountains, listOf(
                v("Alpine Dawn", 0xFF355C7D, 0xFFF8B195, 0xFFFFF1C1, 0xFF1F2A44),
                v("Misty Valley", 0xFF2C3E50, 0xFF8FB8A8, 0xFFE8F5E9, 0xFF14281F),
                v("Golden Ridge", 0xFF3D2C5C, 0xFFFFB347, 0xFFFFE9A8, 0xFF1A1230),
                v("Blue Hour", 0xFF0B132B, 0xFF4F6D9A, 0xFFDCE8FF, 0xFF070B18)
            )
        ),
        Definition(
            WallpaperCategory.Space, ArtStyle.Galaxy, listOf(
                v("Nebula Drift", 0xFF05010F, 0xFF7B2FF7, 0xFF00D4FF, 0xFFC9A0FF),
                v("Ember Cluster", 0xFF0A0305, 0xFFFF5E3A, 0xFFFFC857, 0xFFFFB38A),
                v("Deep Blue", 0xFF010A1A, 0xFF1E5BFF, 0xFF18E0C1, 0xFF8EC5FF),
                v("Gold Dust", 0xFF050505, 0xFFFFD600, 0xFFFF7A00, 0xFFFFE9A0)
            )
        ),
        Definition(
            WallpaperCategory.Abstract, ArtStyle.Waves, listOf(
                v("Liquid Gold", 0xFF0A0A0A, 0xFF1C1500, 0xFFFFD600, 0xFFFF8F00),
                v("Aurora Flow", 0xFF050B1F, 0xFF0E1F4D, 0xFF00E5A8, 0xFF7B61FF),
                v("Magenta Tide", 0xFF14001F, 0xFF33004D, 0xFFFF2E93, 0xFFFFB86B),
                v("Ocean Glass", 0xFF03101C, 0xFF062B45, 0xFF2EC4FF, 0xFF9AF6E3)
            )
        ),
        Definition(
            WallpaperCategory.Minimal, ArtStyle.Minimal, listOf(
                v("Ink Circle", 0xFF0B0B0B, 0xFF151515, 0xFFFFD600, 0xFF2A2A2A),
                v("Paper Sun", 0xFFF1EDE4, 0xFFE3DCCD, 0xFFE4572E, 0xFF2B2B2B),
                v("Soft Dusk", 0xFF1D1B2F, 0xFF3A3560, 0xFFFFC9A9, 0xFF8C84C4),
                v("Mono Slate", 0xFF1A1D21, 0xFF2B3036, 0xFFE8E8E8, 0xFF5C6670)
            )
        )
    )

    val all: List<WallpaperItem> = buildList {
        for (def in definitions) {
            def.variants.forEachIndexed { index, variant ->
                add(
                    WallpaperItem(
                        id = "builtin:${def.category.name.lowercase()}-${index + 1}",
                        title = variant.title,
                        category = def.category,
                        source = WallpaperSource.Procedural(
                            style = def.style,
                            palette = variant.palette,
                            seed = def.category.ordinal * 100L + index
                        ),
                        featured = index == 0,
                        trending = index == 2
                    )
                )
            }
        }
    }

    val featured: List<WallpaperItem> = all.filter { it.featured }
    val trending: List<WallpaperItem> = all.filter { it.trending }

    fun byCategory(category: WallpaperCategory): List<WallpaperItem> =
        all.filter { it.category == category }

    /** Matches title or category name. [extra] lets imported photos take part in the search. */
    fun search(query: String, extra: List<WallpaperItem> = emptyList()): List<WallpaperItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return (all + extra).filter {
            it.title.lowercase().contains(q) || it.category.label.lowercase().contains(q)
        }
    }
}
