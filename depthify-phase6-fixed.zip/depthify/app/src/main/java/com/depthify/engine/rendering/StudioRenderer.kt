package com.depthify.engine.rendering

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import java.io.File
import kotlin.math.max

/** Shared renderer for the editor preview and final exported wallpaper. */
data class StudioTextLayer(
    val id: Long,
    val text: String,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val color: Int = Color.WHITE,
    val size: Float = 54f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val opacity: Float = 1f,
    val shadow: Boolean = true,
    val outline: Boolean = false,
    val alignment: String = "center",
    val visible: Boolean = true,
    val locked: Boolean = false
)

data class StudioRenderOptions(
    val backgroundColor: Int = Color.BLACK,
    val backgroundBrightness: Float = 1f,
    val backgroundBlur: Float = 0f,
    val foregroundBrightness: Float = 1f,
    val foregroundScale: Float = 1f,
    val foregroundX: Float = 0.5f,
    val foregroundY: Float = 0.5f,
    val foregroundRotation: Float = 0f,
    val foregroundVisible: Boolean = true,
    val backgroundVisible: Boolean = true
)

object StudioRenderer {
    fun render(
        foregroundFile: File,
        backgroundFile: File?,
        width: Int,
        height: Int,
        options: StudioRenderOptions,
        texts: List<StudioTextLayer>
    ): Bitmap {
        require(width in 256..4096 && height in 256..4096) { "Resolution must be between 256 and 4096 pixels." }
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val bgBitmap = backgroundFile?.takeIf { it.exists() }?.let { decodeSampled(it, 4096) }
        if (options.backgroundVisible) {
            canvas.drawColor(options.backgroundColor)
            if (bgBitmap != null) {
                val scale = max(width.toFloat() / bgBitmap.width, height.toFloat() / bgBitmap.height)
                val dw = bgBitmap.width * scale
                val dh = bgBitmap.height * scale
                val dst = RectF((width - dw) / 2f, (height - dh) / 2f, (width + dw) / 2f, (height + dh) / 2f)
                bg.colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix().apply {
                    setScale(options.backgroundBrightness, options.backgroundBrightness, options.backgroundBrightness, 1f)
                })
                val blurred = if (options.backgroundBlur > 0f) {
                    val divisor = (options.backgroundBlur.coerceIn(1f, 24f) / 2f).toInt().coerceIn(1, 12)
                    val small = Bitmap.createScaledBitmap(bgBitmap, (bgBitmap.width / divisor).coerceAtLeast(1), (bgBitmap.height / divisor).coerceAtLeast(1), true)
                    Bitmap.createScaledBitmap(small, bgBitmap.width, bgBitmap.height, true).also { if (small !== bgBitmap) small.recycle() }
                } else bgBitmap
                canvas.drawBitmap(blurred, null, dst, bg)
                if (blurred !== bgBitmap) blurred.recycle()
                bg.colorFilter = null
            }
        } else canvas.drawColor(Color.TRANSPARENT)
        if (options.foregroundVisible) {
            val fg = decodeSampled(foregroundFile, 4096)
            if (fg != null) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix().apply {
                        setScale(options.foregroundBrightness, options.foregroundBrightness, options.foregroundBrightness, 1f)
                    })
                }
                val fit = minOf(width.toFloat() / fg.width, height.toFloat() / fg.height)
                val scale = fit * options.foregroundScale.coerceIn(0.2f, 4f)
                val w = fg.width * scale
                val h = fg.height * scale
                canvas.save()
                canvas.rotate(options.foregroundRotation, options.foregroundX * width, options.foregroundY * height)
                canvas.drawBitmap(fg, null, RectF(options.foregroundX * width - w / 2, options.foregroundY * height - h / 2, options.foregroundX * width + w / 2, options.foregroundY * height + h / 2), paint)
                canvas.restore()
                fg.recycle()
            }
        }
        texts.filter { it.visible && it.text.isNotBlank() }.forEach { layer ->
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = layer.color
                alpha = (layer.opacity.coerceIn(0f, 1f) * 255).toInt()
                textSize = layer.size.coerceIn(12f, 240f) * layer.scale.coerceIn(0.3f, 3f) * (width / 1080f).coerceAtLeast(0.35f)
                typeface = Typeface.create(Typeface.SANS_SERIF, when {
                    layer.bold && layer.italic -> Typeface.BOLD_ITALIC
                    layer.bold -> Typeface.BOLD
                    layer.italic -> Typeface.ITALIC
                    else -> Typeface.NORMAL
                })
                textAlign = when (layer.alignment) { "left" -> Paint.Align.LEFT; "right" -> Paint.Align.RIGHT; else -> Paint.Align.CENTER }
                if (layer.shadow) setShadowLayer(8f, 0f, 4f, Color.BLACK)
            }
            canvas.save()
            canvas.rotate(layer.rotation, layer.x * width, layer.y * height)
            if (layer.outline) {
                val stroke = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.BLACK; clearShadowLayer() }
                canvas.drawText(layer.text, layer.x * width, layer.y * height, stroke)
            }
            canvas.drawText(layer.text, layer.x * width, layer.y * height, paint)
            canvas.restore()
        }
        bgBitmap?.recycle()
        return output
    }

    private fun decodeSampled(file: File, maxDimension: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        })
    }
}
