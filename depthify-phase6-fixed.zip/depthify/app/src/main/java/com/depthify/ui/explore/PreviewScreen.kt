package com.depthify.ui.explore

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.depthify.core.models.WallpaperItem
import com.depthify.engine.rendering.WallpaperLoader
import com.depthify.ui.components.GhostButton
import com.depthify.ui.components.GoldButton
import com.depthify.ui.components.LoadingIndicator
import com.depthify.ui.gallery.BitmapState
import com.depthify.ui.gallery.GalleryViewModel
import com.depthify.ui.gallery.rememberWallpaperBitmap
import com.depthify.ui.theme.DepthAccent
import com.depthify.ui.theme.DepthSurface
import com.depthify.ui.theme.DepthSurfaceAlt
import com.depthify.ui.theme.DepthTextPrimary
import com.depthify.ui.theme.DepthTextSecondary
import com.depthify.wallpaper.manager.WallpaperTarget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PreviewScreen(vm: GalleryViewModel, onBack: () -> Unit) {
    val items = vm.previewItems
    if (items.isEmpty()) {
        // Preview state was lost (for example after the app was restarted): go back.
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val pagerState = rememberPagerState(
        initialPage = vm.previewStart.coerceIn(0, items.lastIndex),
        pageCount = { items.size }
    )
    val item = items[pagerState.currentPage.coerceIn(0, items.lastIndex)]
    val isFavorite = item.id in favorites

    var showApply by remember { mutableStateOf(false) }
    var showRemove by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var pendingSave by remember { mutableStateOf<WallpaperItem?>(null) }

    fun doSave(target: WallpaperItem) {
        scope.launch {
            busy = true
            val result = vm.saveToGallery(target)
            busy = false
            snackbar.showSnackbar(
                result.fold(
                    onSuccess = { "Saved to Pictures/DEPTHIFY" },
                    onFailure = { it.message ?: "Could not save the image." }
                )
            )
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val target = pendingSave
        pendingSave = null
        if (granted && target != null) {
            doSave(target)
        } else {
            scope.launch { snackbar.showSnackbar("Storage permission is needed to save on this Android version.") }
        }
    }

    val onSave: () -> Unit = {
        val needsPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pendingSave = item
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            doSave(item)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            PreviewImage(items[page], vm.loader)
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent)))
                .statusBarsPadding()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RoundIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", Color.White, onBack)
            Column(Modifier.weight(1f)) {
                Text(item.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
                Text(
                    item.category.label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }
            RoundIconButton(
                icon = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                description = if (isFavorite) "Remove from favorites" else "Add to favorites",
                tint = if (isFavorite) DepthAccent else Color.White,
                onClick = { vm.toggleFavorite(item.id) }
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                .navigationBarsPadding()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ResolutionLine(item, vm.loader)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GoldButton(
                    text = "Apply",
                    onClick = { showApply = true },
                    modifier = Modifier.weight(1f),
                    icon = Icons.Filled.Wallpaper,
                    enabled = !busy
                )
                if (item.isImported) {
                    GhostButton(
                        text = "Remove",
                        onClick = { showRemove = true },
                        modifier = Modifier.weight(1f),
                        icon = Icons.Filled.Delete
                    )
                } else {
                    GhostButton(
                        text = "Save",
                        onClick = onSave,
                        modifier = Modifier.weight(1f),
                        icon = Icons.Filled.Download
                    )
                }
            }
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 136.dp, start = 16.dp, end = 16.dp)
        ) { data ->
            Snackbar(snackbarData = data, containerColor = DepthSurfaceAlt, contentColor = DepthTextPrimary)
        }

        if (busy) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                LoadingIndicator(message = "Working…")
            }
        }
    }

    if (showApply) {
        ApplyDialog(
            onDismiss = { showApply = false },
            onPick = { target ->
                showApply = false
                scope.launch {
                    busy = true
                    val result = vm.applyWallpaper(item, target)
                    busy = false
                    snackbar.showSnackbar(
                        result.fold(
                            onSuccess = { "Wallpaper applied" },
                            onFailure = { it.message ?: "Could not apply the wallpaper." }
                        )
                    )
                }
            }
        )
    }

    if (showRemove) {
        AlertDialog(
            onDismissRequest = { showRemove = false },
            containerColor = DepthSurface,
            titleContentColor = DepthTextPrimary,
            textContentColor = DepthTextSecondary,
            title = { Text("Remove this photo?") },
            text = {
                Text("This removes DEPTHIFY's copy only. The original photo in your gallery is not touched.")
            },
            confirmButton = {
                TextButton(onClick = {
                    showRemove = false
                    vm.deleteImported(item)
                    onBack()
                }) { Text("Remove", color = DepthAccent) }
            },
            dismissButton = {
                TextButton(onClick = { showRemove = false }) { Text("Cancel", color = DepthTextSecondary) }
            }
        )
    }
}

@Composable
private fun PreviewImage(item: WallpaperItem, loader: WallpaperLoader) {
    val state = rememberWallpaperBitmap(item, loader.previewWidth, loader.previewHeight)
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when (state) {
            is BitmapState.Ready -> Image(
                bitmap = state.image,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            BitmapState.Loading -> LoadingIndicator()
            BitmapState.Failed -> Text(
                "This image could not be loaded.",
                style = MaterialTheme.typography.bodyMedium,
                color = DepthTextSecondary
            )
        }
    }
}

@Composable
private fun ResolutionLine(item: WallpaperItem, loader: WallpaperLoader) {
    val label by produceState("Reading size…", item.id) {
        value = withContext(Dispatchers.IO) { loader.resolutionLabel(item) }
    }
    Text(label, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.75f))
}

@Composable
private fun RoundIconButton(icon: ImageVector, description: String, tint: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0x66000000))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun ApplyDialog(onDismiss: () -> Unit, onPick: (WallpaperTarget) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DepthSurface,
        titleContentColor = DepthTextPrimary,
        textContentColor = DepthTextSecondary,
        title = { Text("Apply wallpaper") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Choose where to use it.")
                GoldButton("Home screen", { onPick(WallpaperTarget.Home) }, Modifier.fillMaxWidth())
                GhostButton("Lock screen", { onPick(WallpaperTarget.Lock) }, Modifier.fillMaxWidth())
                GhostButton("Home and lock screen", { onPick(WallpaperTarget.Both) }, Modifier.fillMaxWidth())
                Text(
                    "Some phone makers limit or override lock-screen wallpapers. If the lock screen does not change, try Home and lock screen, or set it from your phone's own wallpaper settings.",
                    style = MaterialTheme.typography.labelMedium
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = DepthTextSecondary) }
        }
    )
}
