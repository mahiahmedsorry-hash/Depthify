package com.depthify.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.depthify.ui.components.GhostButton
import com.depthify.ui.components.GlassCard
import com.depthify.ui.components.ScreenContainer
import com.depthify.ui.theme.DepthTextPrimary
import com.depthify.ui.theme.DepthTextSecondary

@Suppress("DEPRECATION")
@Composable
fun SettingsScreen(onReplayOnboarding: () -> Unit) {
    val context = LocalContext.current
    val version = remember {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull() ?: "unknown"
    }

    ScreenContainer(title = "Settings", subtitle = "App preferences and information") {
        GlassCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Privacy", style = MaterialTheme.typography.titleMedium, color = DepthTextPrimary)
                Text(
                    "Your photos stay on this device. There are no accounts, no analytics and no tracking. DEPTHIFY asks only for the permission to set your wallpaper, plus storage access on Android 8 and 9 to save images. Photos are chosen with the system photo picker.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DepthTextSecondary
                )
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Welcome tour", style = MaterialTheme.typography.titleMedium, color = DepthTextPrimary)
                    Text(
                        "Watch the introduction screens again.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DepthTextSecondary
                    )
                }
                GhostButton(
                    text = "Replay tour",
                    onClick = onReplayOnboarding,
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Filled.PlayCircle
                )
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("About", style = MaterialTheme.typography.titleMedium, color = DepthTextPrimary)
                Text(
                    "DEPTHIFY version $version",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DepthTextSecondary
                )
                Text(
                    "YOUR WALLPAPER. YOUR DEPTH.",
                    style = MaterialTheme.typography.labelMedium,
                    color = DepthTextSecondary
                )
            }
        }
    }
}
