package com.depthify.ui.library

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.depthify.data.repository.WallpaperCatalog
import com.depthify.ui.components.EmptyState
import com.depthify.ui.components.GlassCard
import com.depthify.ui.components.SectionHeader
import com.depthify.ui.gallery.GalleryViewModel
import com.depthify.ui.gallery.ImportSection
import com.depthify.ui.gallery.WallpaperThumb
import com.depthify.ui.theme.DepthTextPrimary
import com.depthify.ui.theme.DepthTextSecondary

@Composable
fun LibraryScreen(vm: GalleryViewModel, onOpenPreview: () -> Unit) {
    val imported by vm.imported.collectAsStateWithLifecycle()
    val favoriteIds by vm.favorites.collectAsStateWithLifecycle()
    val importState by vm.importState.collectAsStateWithLifecycle()

    val favorites = remember(favoriteIds, imported) {
        (WallpaperCatalog.all + imported).filter { it.id in favoriteIds }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importPhoto(uri)
    }
    val launchPicker = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("My Wallpapers", style = MaterialTheme.typography.headlineLarge, color = DepthTextPrimary)
                Text(
                    "Favorites and imported photos. Saved projects arrive in Phase 7.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DepthTextSecondary
                )
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) { SectionHeader("Favorites") }
        if (favorites.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                GlassCard(Modifier.fillMaxWidth()) {
                    EmptyState(
                        icon = Icons.Outlined.FavoriteBorder,
                        title = "No favorites yet",
                        message = "Tap the heart on a wallpaper to keep it here."
                    )
                }
            }
        } else {
            itemsIndexed(favorites, key = { _, entry -> "fav:" + entry.id }) { index, entry ->
                WallpaperThumb(
                    item = entry,
                    isFavorite = true,
                    onClick = {
                        vm.openPreview(favorites, index)
                        onOpenPreview()
                    }
                )
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) { SectionHeader("My photos") }
        item(span = { GridItemSpan(maxLineSpan) }) {
            ImportSection(state = importState, onImport = { launchPicker() })
        }
        itemsIndexed(imported, key = { _, entry -> "photo:" + entry.id }) { index, entry ->
            WallpaperThumb(
                item = entry,
                isFavorite = entry.id in favoriteIds,
                onClick = {
                    vm.openPreview(imported, index)
                    onOpenPreview()
                }
            )
        }
    }
}
