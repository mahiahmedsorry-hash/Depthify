# DEPTHIFY — YOUR WALLPAPER. YOUR DEPTH.

Native Android depth-wallpaper app (Kotlin + Jetpack Compose). Premium AMOLED dark + gold.
All image processing is planned to run on-device. No cloud upload, no analytics.

## Build the APK (no Android Studio needed)
1. Create a GitHub repository and upload every file in this project (keep the `.github` folder).
2. Open the **Actions** tab, choose **Build APK**, press **Run workflow** (it also runs on every push to `main`).
3. When the run turns green, open it and download the **depthify-debug-apk** artifact. Unzip it and install `app-debug.apk` on your phone (allow "install unknown apps").
4. If the run fails, open the failed step, copy the red error lines (or download the **build-reports** artifact) and send them to Claude.

## Build with Android Studio
Open this folder in Android Studio (Ladybug or newer, JDK 17). If it asks for a Gradle version, use 8.10.2.
Command line: `gradle assembleDebug` (output: `app/build/outputs/apk/debug/`).
The Gradle wrapper jar is not bundled; run `gradle wrapper --gradle-version 8.10.2` once if you want `./gradlew`.

## Stack
Kotlin 2.0.21 · AGP 8.7.3 · Compose BOM 2024.12.01 · Material 3 · Navigation Compose 2.8.5 · DataStore · minSdk 26 · targetSdk 35

## Roadmap
| Phase | Scope | Status |
|---|---|---|
| 1 | Project setup, theme, navigation, UI shell, onboarding, splash, icon | Built by GitHub Actions, APK downloaded |
| 2 | Wallpaper gallery and image import | Written, not yet compiled or run |
| 3 | Segmentation and transparent foreground | Not started |
| 4 | Layer composition and depth rendering | Not started |
| 5 | Text, clock, date, advanced editor | Not started |
| 6 | Static export and live wallpaper | Not started |
| 7 | Room database, testing, optimization, release | Not started |

## What Phase 2 adds
- Built-in collection: 9 categories x 4 original wallpapers, drawn in code (no bundled images, no third-party art). Anime, Cars, Aircraft, Football, Gaming, Nature, Space, Abstract, Minimal.
- Explore: category chips, lazy 2-column grid with cached thumbnails, fullscreen swipe preview, resolution info, favorites.
- Apply as Home, Lock or Both screen. Save to Pictures/DEPTHIFY.
- Home: Featured and Trending rows, category shortcuts, live search (titles and categories, including your photos).
- Import: Android Photo Picker (no permission). An untouched copy goes to app-private storage; it appears under Custom and in Library. Photos can be removed again (only the app copy).
- Library: favorites and imported photos.

## Permissions
- `SET_WALLPAPER` (normal permission, install time) to apply wallpapers.
- `WRITE_EXTERNAL_STORAGE`, limited to Android 8 and 9 (`maxSdkVersion=28`), only to save images. Android 10+ saves through MediaStore with no permission.
- No internet permission, no analytics.

## Testing report (Phase 2)
Nothing has been compiled or run yet. Please check on a real phone and report results:
- [ ] GitHub Actions build succeeds (paste the red error lines if not)
- [ ] Explore shows 4 wallpapers per category; thumbnails load; scrolling is smooth
- [ ] Tap a wallpaper: fullscreen preview opens, swiping changes wallpaper, back works
- [ ] Heart toggles; favorite shows in Library and survives an app restart
- [ ] Apply > Home screen changes the home wallpaper
- [ ] Apply > Lock screen and Home and lock screen behave as expected on your phone brand
- [ ] Save puts a PNG in Pictures/DEPTHIFY (Android 8-9: permission prompt appears first)
- [ ] Home search finds "space", "gold", etc.; Featured and Trending rows open the preview
- [ ] Custom > Import a photo: picker opens, photo appears, preview shows the right rotation
- [ ] Importing a very large photo (50 MP or more) does not crash
- [ ] Remove deletes only the app copy; the original is still in your gallery

## Known limitations
- Wallpapers are generated artwork (illustrative scenes), not photographs. Anime, Cars, Aircraft, Football and Gaming use original stylised scenes, not licensed characters or brands.
- Imported photos are center-cropped to your screen shape for preview and Apply. The untouched original is kept.
- Lock-screen wallpaper support differs by phone maker; some ignore or override it.
- Preview list is held in memory; if Android kills the app while a preview is open, you are returned to the previous screen.
- Segmentation, layers, editor, clock, live wallpaper and the project database are still to come (Phases 3 to 7).
- Icons use the full Material extended set; release shrinking (R8) comes in Phase 7.
- No release signing configured.
