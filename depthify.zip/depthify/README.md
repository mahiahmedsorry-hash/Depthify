# DEPTHIFY — YOUR WALLPAPER. YOUR DEPTH.

Native Android depth-wallpaper app (Kotlin + Jetpack Compose). Premium AMOLED dark + gold.
All image processing is planned to run on-device. No cloud upload, no analytics.

## Build the APK (no Android Studio needed)
1. Create a GitHub repository and upload every file in this project (keep the `.github` folder).
2. Open the **Actions** tab, choose **Build APK**, press **Run workflow** (it also runs on every push to `main`).
3. When the run turns green, open it and download the **depthify-debug-apk** artifact. Unzip it and install `app-debug.apk` on your phone (allow "install unknown apps").
4. If the run fails, open the failed step, copy the red error lines (or download the **build-reports** artifact) and send them to Claude.

## Build with Android Studio
Open this folder in Android Studio (Ladybug or newer, JDK 17). If it asks for a Gradle version, use 8.10.2.
Command line: `gradle assembleDebug` (output: `app/build/outputs/apk/debug/`).
The Gradle wrapper jar is not bundled; run `gradle wrapper --gradle-version 8.10.2` once if you want `./gradlew`.

## Stack
Kotlin 2.0.21 · AGP 8.7.3 · Compose BOM 2024.12.01 · Material 3 · Navigation Compose 2.8.5 · DataStore · minSdk 26 · targetSdk 35

## Roadmap
| Phase | Scope | Status |
|---|---|---|
| 1 | Project setup, theme, navigation, UI shell, onboarding, splash, icon | Written, not yet compiled or run |
| 2 | Wallpaper gallery and image import | Not started |
| 3 | Segmentation and transparent foreground | Not started |
| 4 | Layer composition and depth rendering | Not started |
| 5 | Text, clock, date, advanced editor | Not started |
| 6 | Static export and live wallpaper | Not started |
| 7 | Room database, testing, optimization, release | Not started |

## Testing report (Phase 1)
Nothing has been compiled or run yet. Please check on a real phone and report results:
- [ ] GitHub Actions build succeeds
- [ ] App installs and launches, splash shows, then onboarding
- [ ] Onboarding Next / Skip / Get started work and are remembered after restart
- [ ] All five tabs open; tab selection highlights correctly
- [ ] Home buttons and category chips jump to Create / Explore
- [ ] Explore chips switch category
- [ ] Settings > Replay tour returns to onboarding
- [ ] Layout looks right under the status bar and above the navigation bar

## Known limitations (Phase 1)
- Gallery, import, segmentation, editor, clock, export, live wallpaper and database are not built yet. Sections that depend on them are labelled with their phase.
- Icons use the full Material extended set; release shrinking (R8) comes in Phase 7.
- Fonts are system fonts for now; bundled fonts arrive with the editor.
- No release signing configured.
