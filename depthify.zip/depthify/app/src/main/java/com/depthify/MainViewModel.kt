package com.depthify

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.depthify.data.preferences.UserPreferences
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = UserPreferences(app)

    /** null while the stored value is still loading. */
    val onboardingDone: StateFlow<Boolean?> =
        prefs.onboardingDone.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun setOnboardingDone(done: Boolean) {
        viewModelScope.launch { prefs.setOnboardingDone(done) }
    }
}
