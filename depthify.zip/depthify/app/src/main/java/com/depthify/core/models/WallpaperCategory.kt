package com.depthify.core.models

enum class WallpaperCategory(val label: String) {
    Anime("Anime"),
    Cars("Cars"),
    Aircraft("Aircraft"),
    Football("Football"),
    Gaming("Gaming"),
    Nature("Nature"),
    Space("Space"),
    Abstract("Abstract"),
    Minimal("Minimal"),
    Custom("Custom")
}
