package com.depthify.ui.onboarding

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.depthify.ui.components.GoldButton
import com.depthify.ui.theme.DepthAccent
import com.depthify.ui.theme.DepthBackground
import com.depthify.ui.theme.DepthSurface
import com.depthify.ui.theme.DepthSurfaceAlt
import com.depthify.ui.theme.DepthTextPrimary
import com.depthify.ui.theme.DepthTextSecondary
import kotlinx.coroutines.launch

private data class OnboardPage(val icon: ImageVector, val title: String, val body: String)

@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    val pages = remember {
        listOf(
            OnboardPage(
                Icons.Filled.Layers,
                "Put text behind your subject",
                "Pick one photo. DEPTHIFY separates the person or object so your name, clock or date sits between the background and the subject."
            ),
            OnboardPage(
                Icons.Filled.Lock,
                "Your photos stay on your phone",
                "Editing happens on your device. No account, no tracking and no uploads."
            ),
            OnboardPage(
                Icons.Filled.AutoAwesome,
                "Start simple, go deeper later",
                "Make a wallpaper in a few taps, or open Pro Studio for layers, fonts, effects, clock and date."
            )
        )
    }
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val isLast = pagerState.currentPage == pages.size - 1

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DepthBackground)
            .systemBarsPadding()
            .padding(24.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.End) {
            if (!isLast) {
                TextButton(onClick = onFinished) {
                    Text("Skip", color = DepthTextSecondary)
                }
            }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { index ->
            PageContent(pages[index])
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(pages.size) { i -> Dot(selected = i == pagerState.currentPage) }
        }

        GoldButton(
            text = if (isLast) "Get started" else "Next",
            onClick = {
                if (isLast) {
                    onFinished()
                } else {
                    scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun PageContent(page: OnboardPage) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(180.dp)
                .background(
                    Brush.radialGradient(listOf(DepthAccent.copy(alpha = 0.25f), Color.Transparent)),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .clip(CircleShape)
                    .background(DepthSurface)
                    .border(1.dp, DepthAccent.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(page.icon, contentDescription = null, tint = DepthAccent, modifier = Modifier.size(48.dp))
            }
        }
        Spacer(Modifier.height(40.dp))
        Text(
            page.title,
            style = MaterialTheme.typography.headlineMedium,
            color = DepthTextPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            page.body,
            style = MaterialTheme.typography.bodyLarge,
            color = DepthTextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun Dot(selected: Boolean) {
    val dotWidth by animateDpAsState(if (selected) 24.dp else 8.dp, label = "dot")
    Box(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .height(8.dp)
            .width(dotWidth)
            .clip(CircleShape)
            .background(if (selected) DepthAccent else DepthSurfaceAlt)
    )
}
