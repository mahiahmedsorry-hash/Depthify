package com.depthify.ui.navigation

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.depthify.ui.explore.ExploreScreen
import com.depthify.ui.home.HomeScreen
import com.depthify.ui.library.LibraryScreen
import com.depthify.ui.settings.SettingsScreen
import com.depthify.ui.studio.CreateScreen
import com.depthify.ui.theme.DepthAccent
import com.depthify.ui.theme.DepthBackground
import com.depthify.ui.theme.DepthSurface
import com.depthify.ui.theme.DepthTextSecondary

@Composable
fun MainScaffold(onReplayOnboarding: () -> Unit) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val goTo: (MainTab) -> Unit = { tab ->
        navController.navigate(tab.route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = DepthBackground,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        bottomBar = {
            FloatingCurvedNavigation(
                currentRoute = currentRoute,
                onTabSelected = { if (currentRoute != it.route) goTo(it) }
            )
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = MainTab.Home.route,
            modifier = Modifier.padding(padding),
            enterTransition = { fadeIn(tween(300)) + scaleIn(initialScale = 0.95f, animationSpec = tween(300)) },
            exitTransition = { fadeOut(tween(200)) + scaleOut(targetScale = 1.02f, animationSpec = tween(200)) },
            popEnterTransition = { fadeIn(tween(300)) + scaleIn(initialScale = 0.95f, animationSpec = tween(300)) },
            popExitTransition = { fadeOut(tween(200)) + scaleOut(targetScale = 1.02f, animationSpec = tween(200)) }
        ) {
            composable(MainTab.Home.route) {
                HomeScreen(
                    onOpenCreate = { goTo(MainTab.Create) },
                    onOpenExplore = { goTo(MainTab.Explore) }
                )
            }
            composable(MainTab.Explore.route) { ExploreScreen() }
            composable(MainTab.Create.route) { CreateScreen() }
            composable(MainTab.Library.route) { LibraryScreen() }
            composable(MainTab.Settings.route) {
                SettingsScreen(onReplayOnboarding = onReplayOnboarding)
            }
        }
    }
}

@Composable
fun FloatingCurvedNavigation(
    currentRoute: String?,
    onTabSelected: (MainTab) -> Unit
) {
    val tabs = MainTab.entries
    val currentIndex = tabs.indexOfFirst { it.route == currentRoute }.coerceAtLeast(0)

    // খাঁজটি (Notch) স্প্রিং অ্যানিমেশনে স্লাইড হওয়ার জন্য
    val animatedIndex by animateFloatAsState(
        targetValue = currentIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "notch"
    )

    // সিস্টেম নেভিগেশন বারের নিচে যাতে না ঢুকে যায়
    val bottomPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = 24.dp, 
                end = 24.dp, 
                bottom = bottomPadding + 16.dp // ভেসে থাকার জন্য নিচে গ্যাপ
            )
            .height(72.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val tabWidth = size.width / tabs.size
            val centerX = (animatedIndex + 0.5f) * tabWidth
            val notchRadius = 36.dp.toPx()
            val cornerRadius = 28.dp.toPx() // গোলাকার কর্নার

            val path = Path().apply {
                moveTo(cornerRadius, 0f)
                
                // খাঁজের বাম দিকের কার্ভ
                lineTo(centerX - notchRadius * 1.5f, 0f)
                cubicTo(
                    centerX - notchRadius * 0.5f, 0f,
                    centerX - notchRadius, notchRadius * 0.9f,
                    centerX, notchRadius * 0.9f
                )
                // খাঁজের ডান দিকের কার্ভ
                cubicTo(
                    centerX + notchRadius, notchRadius * 0.9f,
                    centerX + notchRadius * 0.5f, 0f,
                    centerX + notchRadius * 1.5f, 0f
                )
                
                // ডান দিকের গোলাকার কর্নার
                lineTo(size.width - cornerRadius, 0f)
                quadraticBezierTo(size.width, 0f, size.width, cornerRadius)
                lineTo(size.width, size.height - cornerRadius)
                quadraticBezierTo(size.width, size.height, size.width - cornerRadius, size.height)
                
                // বাম দিকের গোলাকার কর্নার
                lineTo(cornerRadius, size.height)
                quadraticBezierTo(0f, size.height, 0f, size.height - cornerRadius)
                lineTo(0f, cornerRadius)
                quadraticBezierTo(0f, 0f, cornerRadius, 0f)
                close()
            }

            // নেভিগেশন বারের ব্যাকগ্রাউন্ড কালার
            drawPath(path = path, color = DepthSurface)

            // নেভিগেশন বারের চারপাশে হালকা একটি বর্ডার (প্রিমিয়াম লুকের জন্য)
            drawPath(
                path = path,
                color = Color.White.copy(alpha = 0.08f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
            )
        }

        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, tab ->
                val selected = currentRoute == tab.route
                
                // সিলেক্টেড আইকনটি খাঁজের ভেতরে উপরে ভেসে থাকবে
                val offsetY by animateFloatAsState(
                    targetValue = if (selected) -26.dp.toPx() else 0f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                    label = "iconFloat"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null // রিপল ইফেক্ট বন্ধ করা হয়েছে যাতে ক্যানভাস পরিষ্কার থাকে
                        ) { onTabSelected(tab) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (selected) tab.selectedIcon else tab.icon,
                        contentDescription = tab.label,
                        tint = if (selected) DepthAccent else DepthTextSecondary,
                        modifier = Modifier
                            .size(28.dp)
                            .graphicsLayer { translationY = offsetY } // আইকন উপরে তোলার জন্য
                    )
                }
            }
        }
    }
}