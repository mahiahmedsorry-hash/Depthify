package com.depthify.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DepthDarkScheme = darkColorScheme(
    primary = DepthAccent,
    onPrimary = Color.Black,
    secondary = DepthAccent,
    onSecondary = Color.Black,
    background = DepthBackground,
    onBackground = DepthTextPrimary,
    surface = DepthSurface,
    onSurface = DepthTextPrimary,
    surfaceVariant = DepthSurfaceAlt,
    onSurfaceVariant = DepthTextSecondary,
    outline = DepthOutline,
    error = DepthError
)

@Composable
fun DepthifyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DepthDarkScheme,
        typography = DepthTypography,
        content = content
    )
}
