package com.depthify.ui.navigation

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.depthify.ui.onboarding.OnboardingScreen
import com.depthify.ui.theme.DepthBackground

@Composable
fun DepthifyApp(
    onboardingDone: Boolean,
    onFinishOnboarding: () -> Unit,
    onReplayOnboarding: () -> Unit
) {
    Box(Modifier.fillMaxSize().background(DepthBackground)) {
        Crossfade(targetState = onboardingDone, animationSpec = tween(350), label = "root") { done ->
            if (done) {
                MainScaffold(onReplayOnboarding = onReplayOnboarding)
            } else {
                OnboardingScreen(onFinished = onFinishOnboarding)
            }
        }
    }
}
