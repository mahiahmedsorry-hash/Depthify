package com.depthify.ui.explore

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.depthify.core.models.WallpaperCategory
import com.depthify.ui.components.CategoryChip
import com.depthify.ui.components.EmptyState
import com.depthify.ui.components.GlassCard
import com.depthify.ui.components.ScreenContainer

@Composable
fun ExploreScreen() {
    var selected by rememberSaveable { mutableIntStateOf(0) }
    val categories = WallpaperCategory.entries.toList()
    val category = categories[selected]

    ScreenContainer(title = "Explore", subtitle = "Browse wallpapers by category") {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(categories) { index, item ->
                CategoryChip(
                    label = item.label,
                    selected = index == selected,
                    onClick = { selected = index }
                )
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            EmptyState(
                icon = Icons.Filled.Image,
                title = "No ${category.label} wallpapers yet",
                message = "The built-in collection, fullscreen preview and favorites arrive in Phase 2."
            )
        }
    }
}
