package com.depthify

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.depthify.ui.navigation.DepthifyApp
import com.depthify.ui.theme.DepthifyTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Keep the splash visible until the saved onboarding state is known.
        splash.setKeepOnScreenCondition { viewModel.onboardingDone.value == null }

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        setContent {
            DepthifyTheme {
                val done by viewModel.onboardingDone.collectAsStateWithLifecycle()
                done?.let { onboardingDone ->
                    DepthifyApp(
                        onboardingDone = onboardingDone,
                        onFinishOnboarding = { viewModel.setOnboardingDone(true) },
                        onReplayOnboarding = { viewModel.setOnboardingDone(false) }
                    )
                }
            }
        }
    }
}
