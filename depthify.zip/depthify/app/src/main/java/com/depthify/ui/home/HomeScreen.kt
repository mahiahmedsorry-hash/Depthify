package com.depthify.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.depthify.core.models.WallpaperCategory
import com.depthify.ui.components.CategoryChip
import com.depthify.ui.components.DepthifyWordmark
import com.depthify.ui.components.GhostButton
import com.depthify.ui.components.GlassCard
import com.depthify.ui.components.GoldButton
import com.depthify.ui.components.PhaseBadge
import com.depthify.ui.components.PlaceholderCard
import com.depthify.ui.components.ScreenContainer
import com.depthify.ui.components.SectionHeader
import com.depthify.ui.theme.DepthTextSecondary

@Composable
fun HomeScreen(onOpenCreate: () -> Unit, onOpenExplore: () -> Unit) {
    ScreenContainer {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            DepthifyWordmark()
            Text(
                "YOUR WALLPAPER. YOUR DEPTH.",
                style = MaterialTheme.typography.labelMedium,
                color = DepthTextSecondary
            )
        }

        // Search arrives together with the wallpaper catalog in Phase 2.
        GlassCard(Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = DepthTextSecondary)
                Text(
                    "Search wallpapers",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodyLarge,
                    color = DepthTextSecondary
                )
                PhaseBadge("Phase 2")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GoldButton("Quick Create", onOpenCreate, Modifier.weight(1f), icon = Icons.Filled.Bolt)
            GhostButton("Depth Studio", onOpenCreate, Modifier.weight(1f), icon = Icons.Filled.Layers)
        }

        SectionHeader("Categories")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(WallpaperCategory.entries.toList()) { category ->
                CategoryChip(label = category.label, selected = false, onClick = onOpenExplore)
            }
        }

        SectionHeader("Featured wallpapers")
        PlaceholderCard(
            icon = Icons.Filled.Star,
            title = "Featured picks",
            message = "Hand-picked wallpapers appear here.",
            badge = "Phase 2"
        )

        SectionHeader("Recently edited")
        PlaceholderCard(
            icon = Icons.Filled.History,
            title = "Nothing edited yet",
            message = "Projects you edit will show up here.",
            badge = "Phase 7"
        )

        SectionHeader("Trending collection")
        PlaceholderCard(
            icon = Icons.Filled.AutoAwesome,
            title = "Trending now",
            message = "The most-used wallpapers appear here.",
            badge = "Phase 2"
        )
    }
}
