package com.depthify.ui.studio

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Layers
import androidx.compose.runtime.Composable
import com.depthify.ui.components.PlaceholderCard
import com.depthify.ui.components.ScreenContainer

@Composable
fun CreateScreen() {
    ScreenContainer(title = "Create", subtitle = "Choose how you want to build your wallpaper") {
        PlaceholderCard(
            icon = Icons.Filled.Bolt,
            title = "Quick Mode",
            message = "Pick a photo, let DEPTHIFY cut out the subject, add a clock and date, then save.",
            badge = "Phase 3"
        )
        PlaceholderCard(
            icon = Icons.Filled.Layers,
            title = "Pro Studio",
            message = "Full control over layers, fonts, effects, clock and date.",
            badge = "Phase 5"
        )
    }
}
