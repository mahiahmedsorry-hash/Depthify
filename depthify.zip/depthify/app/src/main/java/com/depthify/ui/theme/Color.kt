package com.depthify.ui.theme

import androidx.compose.ui.graphics.Color

val DepthBackground = Color(0xFF090909)
val DepthSurface = Color(0xFF151515)
val DepthSurfaceAlt = Color(0xFF202020)
val DepthAccent = Color(0xFFFFD600)
val DepthAccentLight = Color(0xFFFFEA70)
val DepthTextPrimary = Color(0xFFFFFFFF)
val DepthTextSecondary = Color(0xFFA0A0A0)
val DepthOutline = Color(0xFF2E2E2E)
val DepthError = Color(0xFFFF5449)
