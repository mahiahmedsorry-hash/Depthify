package com.depthify.ui.library

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.depthify.ui.components.EmptyState
import com.depthify.ui.components.GlassCard
import com.depthify.ui.components.ScreenContainer

@Composable
fun LibraryScreen() {
    ScreenContainer(title = "My Wallpapers", subtitle = "Your saved projects and favorites") {
        GlassCard(Modifier.fillMaxWidth()) {
            EmptyState(
                icon = Icons.Outlined.PhotoLibrary,
                title = "Nothing saved yet",
                message = "Favorites arrive in Phase 2. Saved projects arrive in Phase 7."
            )
        }
    }
}
